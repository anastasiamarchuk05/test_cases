<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>label_AED 1000 - AED 5000 (28)</name>
   <tag></tag>
   <elementGuidId>1ae9e02a-8f0c-48a2-9d3a-2cebaa5d449b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='Cb2RefinementFacetComponent']/div/div/div/div[2]/div[2]/div/div[3]/label</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>label</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>form-check-label</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>for</name>
      <type>Main</type>
      <value>item-price-AED 1000 - AED 5000</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>AED 1000 - AED 5000 (28)</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;Cb2RefinementFacetComponent&quot;)/div[@class=&quot;leo-product-refinement-component leo-product-refinement-component-product-search-facet-selector-alpha xs-up.filters-title:ff=alpha xs-up.filters-title:txt-case=upper xs-up.filters-title:d=flx xs-up.filters-title:flx-justify-content=between xs-up.filters-title:py=(20px) xs-up.filters-title:px=4 xs-up.filters-title:fs=p4 xs-up.filters-title:bw-bottom=(1px) xs-up.filters-title>>.total-count:ml=auto md-up.filters-title:d=none xs-up:lh=1 xs-up.btn-toggle-filters:mb=4 xs-up.facets:flx-row-align=center-left xs-up.facets:flx-wrap=yes xs-up.facet:mb=3 xs-up.facet:mr=4 xl-up.facet:mr=5 xs-up.facet:pos=rel xs-up.btn-facet-header:btn=body xs-up.btn-facet-header:btn-size=small xs-up.btn-facet-header:fw=normal xs-up.btn-facet-header:p=0 xs-up.btn-facet-header:txt-case=upper xs-up.btn-facet-header:lh=1 xs-up.btn-facet-header:outline=none xs-up.btn-facet-header:w=100 xs-up.btn-facet-header:pos=rel xs-up.btn-facet-header:icon-before=underline-left-to-right xs-up.btn-facet-header:before:bottom=n1 xs-up.btn-facet-header:before:right=4 xs-up.btn-facet-header:before:w=auto xs-up.btn-facet-header:after:ml=2 xs-up.btn-facet-header:after:fw=bold! xs-up.btn-facet-header:not(.state-open):icon-after=chevron-down xs-up.btn-facet-header:after:transition=transform xs-up.btn-facet-header.state-open:icon-after=chevron-up xs-up.btn-facet-header.state-open:icon-before=underline-left-to-right-scale xs-up.facets-backdrop:d=none xs-up.facets-backdrop:pos=abs xs-up.facets-backdrop:top=(4.35rem) xs-up.facets-backdrop:left=0 xs-up.facets-backdrop:w=100 xs-up.facets-backdrop:h=(100vh) xs-up.facets-backdrop:z=9 xs-up.facets-backdrop:bgc=body-50 xs-up.facet-body-wrapper:p=4 xs-up.facet-body-wrapper:bgc=body xs-up.facet-body-wrapper:pos=abs xs-up.facet-body-wrapper:leri=0 xs-up.facet-body-wrapper:z=9 xs-up.facet-body-wrapper:bw=(1px) xs-up.facet-body-wrapper:bc=muted xs-up.facet-body-wrapper:scrollable=none xs-up.facet-body-wrapper:wmin=(15.625rem) xs-up.facet-body-wrapper:top=(1.85rem) xs-up.facet-body:lh=1.5 xs-up.facet-body:scrollable=y xs-up.facet-body:hmax=(18.25rem) xs-up.facet-body:w=100 xs-up.facet-item>>label:txt-truncate=yes xs-up.facet-item>>label:mt=0! xs-up.facet-item>>label:fw=light sm-up.body-controls:flx-order=n1 sm-up.body-controls:w=100 sm-up.body-controls:mb=2 sm-up.body-controls:txt-align=center sm-up.btn-close:my=0 sm-up.btn-close:btn=alpha sm-up.btn-close:py=(0.625rem) sm-up.btn-close:txt-case=upper sm-up.btn-close:fw=normal sm-up.btn-close:w=100 xs-up.btn-clear-all:btn=body xs-up.btn-clear-all:btn-size=small xs-up.btn-clear-all:txt-underline=yes xs-up.btn-clear-all:px=0 xs-up:product-search-facet-selector-beta md-up:product-search-facet-selector-alpha&quot;]/div[1]/div[@class=&quot;facets&quot;]/div[@class=&quot;facet&quot;]/div[@class=&quot;facet-body-wrapper collapse show&quot;]/div[@class=&quot;facet-body&quot;]/div[@class=&quot;facet-item&quot;]/label[@class=&quot;form-check-label&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='Cb2RefinementFacetComponent']/div/div/div/div[2]/div[2]/div/div[3]/label</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='AED 500 - AED 1000 (1)'])[1]/following::label[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='AED 200 - AED 500 (2)'])[1]/following::label[2]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='AED 5000 - AED 10000 (9)'])[1]/preceding::label[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Over AED 10000 (1)'])[1]/preceding::label[2]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='AED 1000 - AED 5000 (28)']/parent::*</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/label</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//label[(text() = 'AED 1000 - AED 5000 (28)' or . = 'AED 1000 - AED 5000 (28)')]</value>
   </webElementXpaths>
</WebElementEntity>
