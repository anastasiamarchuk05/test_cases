<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>profile_wishlist_cart_block</name>
   <tag></tag>
   <elementGuidId>8c0f8479-59b3-4f8b-8698-7dd38ace11ed</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Search'])[1]/following::cx-page-slot[3]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>cx-page-slot.ContentHeaderRight.has-components</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>cx-page-slot</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>ContentHeaderRight has-components</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Sign In / RegisterOrder Tracking0Something catch your eye?Sign in to see items you may have added using another computer or device.Sign in0Are you missing items in your cart?Sign in to see items you may have added using another computer or device.Sign in</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;xs-up:bgc=body xs-up.fa-times:icon-before=cross&quot;]/div[@class=&quot;body&quot;]/div[@class=&quot;xs-up:fc=alpha xs-up:scrollable=none xs-up.icon:w=(1.875rem) xs-up.icon:h=(1.875rem) xs-up.icon:d=inblock xs-up.icon:stroke-width=(1.3867) md-up[leo-page]:px=4 lg-up[leo-page]:px=5 xs-up.MultiStepCheckoutSummaryPageTemplate>[leo-page]:px=0 xs-up.MultiStepCheckoutSummaryPageTemplate+footer:d=none xs-up>>header>>[leo-page]:px=0 xs-up>>footer>>[leo-page]:px=0 md-up.ProductDetailsPageTemplate>[leo-page]:pr=0 xs-up>>picture:wmin=(1px) xs-up>>picture:hmin=(1px) xs-up>>picture:d=block&quot;]/cx-storefront[@class=&quot;stop-navigating&quot;]/header[1]/cx-page-layout[@class=&quot;header&quot;]/div[1]/div[@class=&quot;tpl-LandingPage2Template header-content md-up:px=4 lg-up:px=5 xl-up:px=6&quot;]/div[@class=&quot;container md-up:p=0 xs-up>.row:mx=0 xs-up>.row>.col-slot:p=0 md-up:py=(2rem) xs-up:bw-bottom=(1px) xs-up:bc=muted md-down&lt;&lt;.state-mega-menu-open:bw-bottom=0&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-slot col-3 col-sm-4 xs-up:flx-row-align=center-right xs-up:flx-order=3&quot;]/cx-page-slot[@class=&quot;ContentHeaderRight has-components&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Search'])[1]/following::cx-page-slot[3]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='CB2'])[1]/following::cx-page-slot[4]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[4]/cx-page-slot</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//cx-page-slot[(text() = 'Sign In / RegisterOrder Tracking0Something catch your eye?Sign in to see items you may have added using another computer or device.Sign in0Are you missing items in your cart?Sign in to see items you may have added using another computer or device.Sign in' or . = 'Sign In / RegisterOrder Tracking0Something catch your eye?Sign in to see items you may have added using another computer or device.Sign in0Are you missing items in your cart?Sign in to see items you may have added using another computer or device.Sign in')]</value>
   </webElementXpaths>
</WebElementEntity>
