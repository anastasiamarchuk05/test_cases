<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>product_total</name>
   <tag></tag>
   <elementGuidId>ead3badc-e90b-4891-884f-15fa6b793e3d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='undefined']/div/div/div/div[2]/span</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>total-price xs-up:fs=p2 md-up:fs=p1 xs-up:fw=semi xs-up:mt=2 xs-up:pt=1 md-up:pt=0</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> AED 8,265.00 </value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;CartComponent&quot;)/div[@class=&quot;leo-cart-component leo-cart-component-cart-details-alpha xs-up:cart-details:pos=rel xs-up:cart-details-total:bgc=body xs-up:cart-details-total:d=flx md-up:cart-details-total:d=none xs-up:cart-details-total:flx-dir=col xs-up:cart-details:mb=5 xs-up:total-amount:txt-align=right xs-up:total-tax-label:fs=p3 xs-up:total-tax-label:fw=normal xs-up:total-tax-label:fc=beta-70 xs-up:btn-checkout:my=3 xs-up.cx-promotions>ul:p=0 xs-up.cx-promotions>ul:list-style=none xs-up.cx-promotions>ul>li:p=2 xs-up.cx-promotions>ul>li:my=2 xs-up.cx-promotions>ul>li:bgc=light xs-up.cx-promotions>ul>li:fc=danger xs-up:cart-list:d=flx xs-up:cart-list:flx-dir=col xs-up:cart-list:mt=4 xs-up:cart-list:bw-top=(2px) xs-up:cart-list:bc=alpha md-up:cart-list:bc=mid xs-up:cart-item-top-container:w=100 xs-up:cart-item-top-container:d=flx xs-up:cart-item-top-container:flx-wrap=yes xs-up:cart-item-top-container:p=3 xs-up:cart-item-top-container:pb=1 md-up:cart-item-top-container:bw-bottom=(2px) md-up:cart-item-top-container:bc=light xs-up:cart-item-product-info:pb=3 xs-up:cart-item-product-info:w=100 md-up:cart-item-product-info:w=50 xs-up:cart-item-price-wrapper:w=100 md-up:cart-item-price-wrapper:w=50 xs-up:cart-item-price-wrapper:bw-bottom=(2px) xs-up:cart-item-price-wrapper:bw-top=(2px) xs-up:cart-item-price-wrapper:bc=light md-up:cart-item-price-wrapper:bw=0 xs-up:cart-item-price-wrapper:d=flx xs-up:cart-item-price-wrapper:flx-dir=row xs-up:cart-item-price-wrapper:flx-row-align=top-between xs-up:cart-item-price-wrapper:pt=3 xs-up:cart-item-price-wrapper:pb=2 md-up:cart-item-price-wrapper:pt=0 xs-up:cart-item-price-form-wrapper:d=flx xs-up:cart-item-price-form-wrapper:flx-dir=row xs-up:cart-item-price-form:d=flx xs-up:cart-item-price-form:flx-dir=col xs-up:cart-item-quantity-input:mb=0 xs-up:cart-item-quantity-input:w=(3.75rem) xs-up:cart-item-quantity-input:txt-align=center xs-up:cart-item-quantity-input:fs=p2 md-up:cart-item-quantity-input:fs=p3 xs-up:cart-item-quantity-update:px=2 xs-up:cart-item-quantity-update:fc=link sm-down:cart-item-quantity-update:txt-underline=no xs-up:cart-item-bottom-container:p=3 xs-up:cart-item-bottom-container:w=100 xs-up:cart-item-bottom-container:d=flx xs-up:cart-item-bottom-container:flx-wrap=yes xs-up:cart-item-product-image:w=40 md-up:cart-item-product-image:w=30 xs-up:cart-item-shipment-container:w=50 xs-up:cart-item-item-actions:w=100 md-up:cart-item-item-actions:w=20 xs-up:cart-item-item-actions:d=flx xs-up:cart-item-item-actions:pt=3 md-up:cart-item-item-actions:pt=0 xs-up:cart-item-item-actions:flx-wrap=yes xs-up:cart-item-btn-remove:flx-align-items=center xs-up:cart-item-btn-remove:flx-justify-content=center xs-up:cart-item-btn-remove:bc=light xs-up:cart-item-btn-remove:bw=0 xs-up:cart-item-btn-remove:bw-right=(1px) xs-up:cart-item-btn-remove:bw-bottom=(2px) xs-up:cart-item-btn-remove:bw-top=(2px) md-up:cart-item-btn-remove:bw=0 md-up:cart-item-btn-remove:bw-bottom=(1px) xs-up:cart-item-btn-remove:py=3 md-up:cart-item-btn-remove:py=4 xs-up:cart-item-btn-remove:d=flx xs-up:cart-item-btn-remove:flx-dir=row md-up:cart-item-btn-remove:flx-dir=col xs-up:cart-item-btn-remove:w=50 md-up:cart-item-btn-remove:w=100 xs-up:cart-item-btn-remove:icon-before=remove sm-down.button-remove:before:wmax=(22px)! sm-down.button-remove:before:hmax=(22px)! md-up:cart-item-btn-remove-text:mt=2 xs-up:cart-item-btn-remove-text:ml=(0.75rem) md-up:cart-item-btn-remove-text:mx=auto xs-up:cart-item-btn-add-to-wishlist:bc=light xs-up:cart-item-btn-add-to-wishlist:bw=0 xs-up:cart-item-btn-add-to-wishlist:bw-left=(1px) xs-up:cart-item-btn-add-to-wishlist:bw-top=(2px) xs-up:cart-item-btn-add-to-wishlist:bw-bottom=(2px) md-up:cart-item-btn-add-to-wishlist:bw=0 md-up:cart-item-btn-add-to-wishlist:bw-top=(1px) xs-up:cart-item-btn-add-to-wishlist:flx-align-items=center xs-up:cart-item-btn-add-to-wishlist:flx-justify-content=center xs-up:cart-item-btn-add-to-wishlist:py=3 md-up:cart-item-btn-add-to-wishlist:py=4 xs-up:cart-item-btn-add-to-wishlist:d=flx xs-up:cart-item-btn-add-to-wishlist:flx-dir=row md-up:cart-item-btn-add-to-wishlist:flx-dir=col xs-up:cart-item-btn-add-to-wishlist:w=50 md-up:cart-item-btn-add-to-wishlist:w=100 xs-up.button-save-for-later:icon-before=save-for-later sm-down.button-save-for-later:before:wmax=(22px)! sm-down.button-save-for-later:before:hmax=(22px)! md-up:cart-item-btn-add-to-wishlist-text:mt=2 xs-up:cart-item-btn-add-to-wishlist-text:ml=(0.75rem) md-up:cart-item-btn-add-to-wishlist-text:ml=auto xs-up:cart-list:mt=0 md-up:cart-list:mt=4 xs-up.cart-header:mb=5! xs-up.leo-item-list-item:bw-bottom=(2px) xs-up.leo-item-list-item:pb=(2rem) xs-up:cart-item-product-info:txt-case=upper xs-up:cart-item-product-sku:fw=light xs-up:cart-item-quantity-update:txt-underline=yes xs-up:cart-item-quantity-update:fw=light xs-up:cart-item-quantity-update:fc=inherit xs-up:cart-item-unit-price:fw=light xs-up:cart-item-btn-remove-text:fw=light xs-up:cart-item-btn-add-to-wishlist-text:fw=light xs-up:cart-item-shipment-container:w=0 md-up:cart-item-item-actions:w=70 md-up:cart-item-item-actions:z=3 md-up:cart-item-item-actions:pt=4 md-up:cart-item-item-actions:flx-dir=row lg-up:cart-item-product-image:w=27 lg-up:cart-item-shipment-container:d=none md-up:cart-item-item-actions:flx-wrap=no md-up:cart-item-item-actions:flx-dir=rowrev md-up:cart-item-item-actions:hmax=(120px) md-up:cart-item-btn-remove:bw=(2px) md-up:cart-item-btn-remove:bw-left=0 md-up:cart-item-btn-remove:bc=light md-up:cart-item-btn-remove:wmin=(103px) md-up:cart-item-btn-remove:w=auto md-up:cart-item-btn-add-to-wishlist:bw=(2px) md-up:cart-item-btn-add-to-wishlist:bc=light md-up:cart-item-btn-add-to-wishlist:wmin=(103px) md-up:cart-item-btn-add-to-wishlist:w=auto xs-up.tooltip-inner:wmax=(6rem) md-up.tooltip-inner:wmax=(9rem) md-up:cart-item-top-container:pos=abs md-up:cart-item-top-container:right=(0px) md-up:cart-item-top-container:bw-bottom=(0px) md-up:cart-item-top-container:w=70 md-up:cart-item-top-container:d=block md-up:cart-item-top-container:pl=5 xs-up:cart-item-top-container:px=0 xs-up:cart-item-bottom-container:px=0 md-up:cart-item-product-info:w=70 md-up:cart-item-price-wrapper:w=100 md-up.item-price-wrapper>>.form-wrapper:z=6 md-up.total-price:pos=abs md-up.total-price:top=3 md-up.total-price:right=3 md-up.total-price:mt=0 xs-up:cart-item-bottom-container:flx-align-items=end xs-up.btn-checkout:h=(2.5rem) xs-up.btn-checkout:mb=2! xs-up.btn-checkout:mt=1! xs-up.btn-checkout:fs=p3 xs-up.btn-checkout:ls=.06 xs-up.btn-checkout:txt-case=upper xs-up.additional-text:fs=p5 xs-up.additional-text:fw=light xs-up.additional-text>>.link:txt-underline=yes xs-up.total-price-row:mt=1 xs-up.total-price-row:pt=3 xs-up.total-price-row>>.total-label:wmin=50! xs-up.total-price-row>>.amount:wmax=50! xs-up.cx-promotions:mt=5 xs-up.cx-promotions:mb=n2 md-up.cx-promotions:mb=n4 xs-up.with-tax:fi=no xs-up.with-tax:fc=alpha xs-up.with-tax:fw=light cart-details-alpha&quot;]/div[1]/div[@class=&quot;cart-details-wrapper&quot;]/div[2]/div[@id=&quot;undefined&quot;]/div[@class=&quot;leo-cart-items-list-component leo-cart-items-list-component-cart-list-default cart-list-default&quot;]/div[1]/div[@class=&quot;leo-item-list&quot;]/div[@class=&quot;leo-item-list-item&quot;]/div[1]/div[@id=&quot;undefined&quot;]/div[@class=&quot;leo-cart-item-component leo-cart-item-component-cart-item-default cart-item-default&quot;]/div[1]/div[@class=&quot;top-container&quot;]/div[@class=&quot;item-price-wrapper&quot;]/span[@class=&quot;total-price xs-up:fs=p2 md-up:fs=p1 xs-up:fw=semi xs-up:mt=2 xs-up:pt=1 md-up:pt=0&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='undefined']/div/div/div/div[2]/span</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='AED 2,755.00'])[1]/following::span[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Update'])[1]/following::span[2]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Remove'])[1]/preceding::span[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Save for Later'])[1]/preceding::span[2]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='AED 8,265.00']/parent::*</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/span</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = ' AED 8,265.00 ' or . = ' AED 8,265.00 ')]</value>
   </webElementXpaths>
</WebElementEntity>
