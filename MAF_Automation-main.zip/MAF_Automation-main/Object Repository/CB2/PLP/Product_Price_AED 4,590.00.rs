<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Product_Price_AED 4,590.00</name>
   <tag></tag>
   <elementGuidId>8d090a80-38f1-4e68-a17e-f5f609592d17</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='undefined']/div/div/div</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.price</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>price</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>AED 4,590.00</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;ProductListComponent&quot;)/div[@class=&quot;leo-product-list-component leo-product-list-component-product-grid-alpha-four-columns xs-up:product-grid:pos=rel xs-up:product-grid-col-item-inner:h=100 xs-up:product-grid-container:px=0 xs-up:product-grid-row-group:mb=5 xs-up:product-grid-col-item-inner:pos=rel xs-up.row-badges>.col-item>.col-item-inner:d=flx xs-up:product-grid-col-item-inner:pr=6 xs-up.row-image+.row:mt=gutter-half xs-up.row-image>.col-item>.col-item-inner:px=0! xs-up.row-price>>.col-item-inner:flx-col-align=top-left xs-up.row-price>>.col-item-inner>>.tile-price:flx=fill xs-up.tile-add-to-wishlist:pos=abs xs-up.tile-add-to-wishlist:right=n1 xs-up.tile-add-to-wishlist:top=n1 xs-up.tile-variant-selector-simple>>.variant-group:mb=3 xs-up.tile-variant-selector-advanced>>.features-group:mb=3 xs-up.tile-variant-selected-item>>.variant-list:mb=3 xs-up.tile-name>>.name:mb=2 xs-up.tile-summary>>.summary:mb=3 xs-up.tile-price+.tile:mt=3 xs-up.tile-stock-badge-cta:mt=0! xs-up.tile-stock-badge-cta:flx=fill xs-up.tile-stock-badge-cta+.tile:mt=3 xs-up:product-grid-alpha-two-columns md-up:product-grid-alpha-three-columns lg-up:product-grid-alpha-two-columns xl-up:product-grid-alpha-three-columns xxl-up:product-grid-alpha-four-columns&quot;]/div[1]/div[@class=&quot;container container-grid&quot;]/div[@class=&quot;row-group&quot;]/div[@class=&quot;row row-badge-and-name row-add-to-wishlist row-price row-stock-badge-cta row-variant-selector-simple row-earnable-points-alpha&quot;]/div[@class=&quot;col-item col-3&quot;]/div[@class=&quot;col-item-inner&quot;]/div[@class=&quot;tile tile-price&quot;]/div[@id=&quot;undefined&quot;]/div[@class=&quot;leo-product-price-component leo-product-price-component-product-price-alpha xs-up[leo-product-price]:d=flx xs-up:fs=p5 xs-up:fw=light xs-up.price.state-cross:fc=danger xs-up.price.state-cross:mr=(5px) xs-up.crossed-price:fc=black xs-up.crossed-price:txt-line-through=yes product-price-alpha&quot;]/div[1]/div[@class=&quot;price&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='undefined']/div/div/div</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Add to favorites'])[1]/following::div[5]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Wynn Ivory Concrete Desk'])[1]/following::div[9]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Add to favorites'])[2]/preceding::div[15]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='AED 2,525.00'])[1]/preceding::div[19]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='AED 4,590.00']/parent::*</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div/div[3]/div/div/div/div</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'AED 4,590.00' or . = 'AED 4,590.00')]</value>
   </webElementXpaths>
</WebElementEntity>
