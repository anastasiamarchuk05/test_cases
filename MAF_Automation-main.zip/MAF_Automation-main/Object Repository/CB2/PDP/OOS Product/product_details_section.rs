<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>product_details_section</name>
   <tag></tag>
   <elementGuidId>f805fd6b-1e1b-46e1-a2ca-eeba064d54bb</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='PdpProductInfoGridComponent']/div/div/div/div/div/div[2]/div[13]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.sticky.sticky-enabled > div.wrapper-grid > div.container-grid.container > div.row > div.col-12.col-last.col-item</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>col-12 col-last col-item</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> Details Dimensions</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;PdpProductInfoGridComponent&quot;)/div[@class=&quot;leo-advanced-grid-component leo-advanced-grid-component-product-info-grid xs-up:grid:pos=rel xs-up:grid-bg:pos-overlay=abs xs-up:grid-bg-img:w=100 xs-up:grid-bg-img:h=100 xs-up:grid-bg-img:pos=abs xs-up:grid-bg-img:ofit=cover xs-up:grid-bg-img:opos=center xs-up:grid-col-item:mx=auto xs-up:grid-col-components:h=100 xs-up:grid-col-item:p=0 md-up:grid-col-item:pl=5 lg-up:grid-col-item:pl=6 xl-up:grid-col-item:pl=7 md-up:grid-col-item:ml=0 md-up:grid-col-item:wmax=(575px) product-info-grid&quot;]/div[1]/div[@class=&quot;sticky sticky-enabled&quot;]/div[@class=&quot;wrapper-grid&quot;]/div[@class=&quot;container-grid container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-12 col-last col-item&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='PdpProductInfoGridComponent']/div/div/div/div/div/div[2]/div[13]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='You will be notified when the product is back in stock.'])[1]/following::div[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Add to favorites'])[1]/following::div[12]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[13]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = ' Details Dimensions' or . = ' Details Dimensions')]</value>
   </webElementXpaths>
</WebElementEntity>
