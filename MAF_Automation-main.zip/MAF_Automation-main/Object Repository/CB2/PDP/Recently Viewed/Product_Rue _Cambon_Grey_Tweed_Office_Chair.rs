<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Product_Rue _Cambon_Grey_Tweed_Office_Chair</name>
   <tag></tag>
   <elementGuidId>80b58f4c-b8ad-45fd-802d-d46aee61d65d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(//div[@id='undefined']/div/div/h2/a)[4]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/en/product/rue-cambon-grey-tweed-office-chair/495856_CB2</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> Rue Cambon Grey Tweed Office Chair </value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;ProductListComponent&quot;)/div[@class=&quot;leo-product-list-component leo-product-list-component-product-grid-alpha-four-columns xs-up:product-grid:pos=rel xs-up:product-grid-col-item-inner:h=100 xs-up:product-grid-container:px=0 xs-up:product-grid-row-group:mb=5 xs-up:product-grid-col-item-inner:pos=rel xs-up.row-badges>.col-item>.col-item-inner:d=flx xs-up:product-grid-col-item-inner:pr=6 xs-up.row-image+.row:mt=gutter-half xs-up.row-image>.col-item>.col-item-inner:px=0! xs-up.row-price>>.col-item-inner:flx-col-align=top-left xs-up.row-price>>.col-item-inner>>.tile-price:flx=fill xs-up.tile-add-to-wishlist:pos=abs xs-up.tile-add-to-wishlist:right=n1 xs-up.tile-add-to-wishlist:top=n1 xs-up.tile-variant-selector-simple>>.variant-group:mb=3 xs-up.tile-variant-selector-advanced>>.features-group:mb=3 xs-up.tile-variant-selected-item>>.variant-list:mb=3 xs-up.tile-name>>.name:mb=2 xs-up.tile-summary>>.summary:mb=3 xs-up.tile-price+.tile:mt=3 xs-up.tile-stock-badge-cta:mt=0! xs-up.tile-stock-badge-cta:flx=fill xs-up.tile-stock-badge-cta+.tile:mt=3 xs-up:product-grid-alpha-two-columns md-up:product-grid-alpha-three-columns lg-up:product-grid-alpha-two-columns xl-up:product-grid-alpha-three-columns xxl-up:product-grid-alpha-four-columns&quot;]/div[1]/div[@class=&quot;container container-grid&quot;]/div[@class=&quot;row-group&quot;]/div[@class=&quot;row row-badge-and-name row-add-to-wishlist row-price row-stock-badge-cta row-variant-selector-simple row-earnable-points-alpha&quot;]/div[@class=&quot;col-item col-3&quot;]/div[@class=&quot;col-item-inner&quot;]/div[@class=&quot;tile tile-badge-and-name&quot;]/div[@id=&quot;undefined&quot;]/div[@class=&quot;leo-product-badge-and-name-component leo-product-badge-and-name-component-product-badge-and-name-alpha xs-up.name:fs=p5 xs-up.name:mb=0 xs-up.name:fw=light xs-up.name:lh=1.5 xs-up.name:ls=.08 xs-up.name:txt-case=upper xs-up.name>>a:fc=black xs-up.badges:d=inflx xs-up.badges:flx-dir=rowrev xs-up.badge:fs=p5 xs-up.badge:fc=black xs-up.badge:fw=normal xs-up.badge:txt-case=upper xs-up.badge:mr=2 product-badge-and-name-alpha&quot;]/div[1]/h2[@class=&quot;name&quot;]/a[1]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>(//div[@id='undefined']/div/div/h2/a)[4]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Rue Cambon Grey Tweed Office Chair')]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='AED 1,375.00'])[1]/following::a[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Add to favorites'])[3]/following::a[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Add to favorites'])[4]/preceding::a[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='AED 1,605.00'])[1]/preceding::a[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Rue Cambon Grey Tweed Office Chair']/parent::*</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>(//a[contains(@href, '/en/product/rue-cambon-grey-tweed-office-chair/495856_CB2')])[2]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[4]/div/div/div/div/div/h2/a</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/en/product/rue-cambon-grey-tweed-office-chair/495856_CB2' and (text() = ' Rue Cambon Grey Tweed Office Chair ' or . = ' Rue Cambon Grey Tweed Office Chair ')]</value>
   </webElementXpaths>
</WebElementEntity>
