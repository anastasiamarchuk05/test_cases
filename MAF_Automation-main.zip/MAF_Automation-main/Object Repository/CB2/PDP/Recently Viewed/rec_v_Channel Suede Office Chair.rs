<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>rec_v_Channel Suede Office Chair</name>
   <tag></tag>
   <elementGuidId>1b70325a-be07-485e-9b3d-aa74de64f96b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(//div[@id='undefined']/div/div/div/a/span)[10]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>description</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Channel Suede Office Chair</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;Cb2PdpRecentlyViewedProductsComponent&quot;)/div[@class=&quot;leo-recently-viewed-products-component leo-recently-viewed-products-component-product-carousel-alpha xs-up:carousel-title:fs=p2 xs-up.product-sku:d=none xs-up:carousel-product-item:px=1 xs-up:carousel-product-item:h=100 xs-uo:carousel-item-product-detail:w=100 xs-up:carousel-item-product-info:d=flx xs-up:carousel-item-product-info:flx-dir=col xs-up:carousel-item-product-info:my=1 xs-up:carousel-item-product-info-price:fw=semi xs-up:carousel-item-product-info-has-crossed-price:fc=danger xs-up:carousel-item-product-info-crossed-price:fc=beta xs-up:carousel-item-product-info-crossed-price:fw=regular xs-up:carousel-item-product-add-to-cart:d=none xs-up:carousel-item-product-add-to-cart-input:wmax=20 xs-up:carousel-item-product-add-to-cart-input:txt-align=center xs-up:carousel-item-product-add-to-cart-input:mb=0 xs-up:carousel-item-product-add-to-cart-input:mr=2 xs-up:mt=2 md-up:mt=5 xs-up:carousel:mt=0 xs-up:carousel:mb=4 xs-up:carousel:pb=4 md-up:wmin=(100%) xs-up:carousel:z=99 xs-up:carousel-title:txt-case=upper xs-up:carousel-title:pt=4 xs-up:carousel-title:mb=3 xs-up:carousel-title:fw=normal xs-up:carousel-title:fs=p3! md-up:carousel-title:fs=h6! xs-up:carousel-title:ls=.12! xs-down:carousel-product-item:px=0 xs-down:carousel-product-item:w=(97%) xs-up:carousel-tagline:fp=3 md-up:carousel-tagline:fp=2 md-up:carousel-tagline:fw=normal sm-down:carousel-tagline:txt-case=upper xs-up:carousel-headline:d=none md-up:carousel-headline:d=block xs-up:carousel-headline:fw=normal! xs-up:carousel-headline:fh=6 sm-up:carousel-headline:fh=4 md-up:carousel-headline:fh=5 lg-up:carousel-headline:fh=4 xs-up:directions:d=none xs-up.indicators:d=none! xs-up.carousel-item:pos=rel xs-up.carousel-item:txt-align=center xs-up.carousel-item:fs=p4 md-up:directions:d=flx md-up.btn:px=(0.60rem) md-up.left:right=0! md-up.left>>.btn-primary:pos=abs md-up.left>>.btn-primary:right=(100px) md-up.left>>.btn-primary:top=(-50px) md-up.right>>.btn-primary:pos=abs md-up.right>>.btn-primary:right=(50px) md-up.right>>.btn-primary:top=(-50px) md-up.btn-primary:focus:bs=none! md-up.icon-next:icon-before=chevron-right md-up.icon-prev:icon-before=chevron-left md-up.icon-next:fs=(18px) md-up.icon-prev:fs=(18px) md-up.icon-next:before:fw=bold md-up.icon-prev:before:fw=bold md-up:direction-buttons:bgc=transparent md-up:direction-buttons:fc=alpha md-up.invisible:d=flx! md-up.invisible:visible=yes md-up.invisible>>button:fc=muted! md-up.invisible>>button:bc=muted md-up.invisible>>button:cursor=default! xs-up.product-info:txt-underline=no xs-up.product-info:txt-case=upper xs-up.product-detail:d=flx md-up.product-detail:opacity=100 xs-up.product-info:txt-align=left xs-up:carousel-item-product-info:mt=(0.75rem) xs-up.product-info>>.description:fw=light! xs-up.product-info>>.product-sku:fw=light! xs-up.price:fw=light! xs-up.has-crossed:mr=2 xs-up.carousel-container>>.wrapper:pr=3 xs-up&lt;&lt;.tpl-ProductDetailsPageTemplate>>.carousel:mb=0 xs-up&lt;&lt;.tpl-ProductDetailsPageTemplate>>.carousel:pb=0 xs-up:product-carousel-gamma md-up:product-carousel-alpha&quot;]/div[1]/ngx-advanced-carousel[@class=&quot;carousel&quot;]/div[@class=&quot;carousel-container&quot;]/div[@class=&quot;carousel&quot;]/div[@class=&quot;content grab&quot;]/div[@class=&quot;item cursor-pointer visible_important&quot;]/div[@class=&quot;slide flex-wrap&quot;]/div[@class=&quot;wrapper&quot;]/div[@class=&quot;carousel-item&quot;]/div[@id=&quot;undefined&quot;]/div[@class=&quot;leo-product-carousel-item-component leo-product-carousel-item-component-product-carousel-item-component-default product-carousel-item-component-default&quot;]/div[1]/div[@class=&quot;product-detail&quot;]/a[@class=&quot;product-info&quot;]/span[@class=&quot;description&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>(//div[@id='undefined']/div/div/div/a/span)[10]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Add to Cart'])[4]/following::span[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='AED 1,375.00'])[1]/following::span[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='AED 3,675.00'])[1]/preceding::span[3]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Add to Cart'])[5]/preceding::span[4]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Channel Suede Office Chair']/parent::*</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//ngx-advanced-carousel/div/div/div/div/div/div[3]/div/div/div/div/div/a/span</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Channel Suede Office Chair' or . = 'Channel Suede Office Chair')]</value>
   </webElementXpaths>
</WebElementEntity>
