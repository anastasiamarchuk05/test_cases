<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>product_title</name>
   <tag></tag>
   <elementGuidId>898332c0-2e2d-4e44-8ec4-fd06a34909c4</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='undefined']/div/div/h1/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>h1.name > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/en/product/court-office-chair/129648_CB2</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Court Office Chair</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;ProductIntroComponent&quot;)/div[@class=&quot;leo-product-intro-component leo-product-intro-component-product-intro-alpha xs-up:mt=4 md-up:mt=0 xs-up:px=3 xs-up.intro-wrapper:d=flx xs-up.intro-wrapper:flx-dir=col xs-up.intro-wrapper:bgc=white! xs-up.intro-wrapper:z=1! xs-up.intro-wrapper:txt-case=upper xs-up[leo-product-intro]:d=flx xs-up[leo-product-intro]:flx-dir=col xs-up.product-sku:flx-order=2 xs-up.intro-wrapper>>.product-price:flx-order=1 xs-up.intro-wrapper>>.product-sku:flx-order=2 product-intro-alpha&quot;]/div[1]/div[@class=&quot;product-name&quot;]/div[@id=&quot;undefined&quot;]/div[@class=&quot;leo-product-name-component leo-product-name-component-product-name-delta xs-up:mb=2 md-up&lt;&lt;[sticky]:mt=2 xs-up:txt-case=upper xs-up.name:fs=p2 md-up.name:fs=h6 xs-up.name:lh=1.25 xs-up.name:ls=.12 xs-up>>a:hover:txt-underline=no xs-up>>a:hover:cursor=(text) product-name-delta&quot;]/div[1]/h1[@class=&quot;name&quot;]/a[1]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='undefined']/div/div/h1/a</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Court Office Chair')]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='On Sale'])[1]/following::a[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Tap To Zoom'])[7]/following::a[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='SKU: 129648_CB2'])[1]/preceding::a[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Limited Time AED 2,065.00'])[1]/preceding::a[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/en/product/court-office-chair/129648_CB2')]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//h1/a</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/en/product/court-office-chair/129648_CB2' and (text() = 'Court Office Chair' or . = 'Court Office Chair')]</value>
   </webElementXpaths>
</WebElementEntity>
