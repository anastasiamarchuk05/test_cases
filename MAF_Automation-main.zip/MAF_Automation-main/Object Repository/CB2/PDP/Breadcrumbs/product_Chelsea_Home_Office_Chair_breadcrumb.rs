<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>product_Chelsea_Home_Office_Chair_breadcrumb</name>
   <tag></tag>
   <elementGuidId>db534400-959b-4dfa-bb1c-3c487d4ec21f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='Cb2PdpBreadcrumbComponent']/div/div/div/div/div/div/ul/li[5]/span</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Chelsea Home Office Chair</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;Cb2PdpBreadcrumbComponent&quot;)/div[@class=&quot;leo-breadcrumb-component leo-breadcrumb-component-breadcrumb-alpha xs-up:fc=mid xs-up:fs=(11px) xs-up:txt-case=upper xs-up:pos=rel xs-up:ls=.06 xs-up:z=1 xs-up.container:my=4 xs-up>>ul:list-style=none xs-up>>ul:flx-row-align=center-left xs-up>>ul:flx-wrap=yes xs-up>>li:fw=light xs-up>>li:not(:first-child):icon-before=slash-right xs-up>>li:before:fs=(17px)! xs-up>>li:before:fw=bold! xs-up>>li:before:px=(0.625rem) xs-up>>a:fc=mid xs-up>>a:hover:txt-underline=yes xl-up.static-page-template>>.container:wmax=normal xs-up.static-page-template>>h1:d=none md-down.account-page-template:d=none xl-up.account-page-template>>.container:wmax=normal xl-up.register-page-template>>.container:wmax=normal xs-up.static-page-template-about-us:d=none xs-up.landing-page2-template:d=none xs-up.login-page-template:d=none xs-up.cart-page-template:d=none xs-up.search-results-list-page-template:d=none md-down.category-page-template:d=none md-down.category-page-level1-template:d=none md-down.category-page-level2-template:d=none xs-up.category-page-level2-template:mx=(-0.25rem) md-down.product-details-page-template:d=none xs-up.product-details-page-template>>.container:px=0 xs-up.product-details-page-template>>.row:mx=0 xs-up.product-details-page-template>>.col-12:px=0 xs-up.category-page-template>>.container:px=0 xs-up.category-page-template>>.container:mb=0 xs-up.category-page-template>>.row:mx=0 xs-up.category-page-template>>.col-12:px=0 breadcrumb-alpha&quot;]/div[1]/div[@class=&quot;product-details-page-template product-details-page-template-product-details&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-12&quot;]/ul[1]/li[5]/span[1]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='Cb2PdpBreadcrumbComponent']/div/div/div/div/div/div/ul/li[5]/span</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Office Chairs'])[2]/following::span[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Office Chairs'])[1]/following::span[2]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Tap To Zoom'])[1]/preceding::span[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Tap To Zoom'])[2]/preceding::span[2]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Chelsea Home Office Chair']/parent::*</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[5]/span</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Chelsea Home Office Chair' or . = 'Chelsea Home Office Chair')]</value>
   </webElementXpaths>
</WebElementEntity>
