<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>cart_summary_section</name>
   <tag></tag>
   <elementGuidId>a89dbea3-4424-4d51-8a56-4efb068d52f7</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Shopping is always safe and secure.'])[1]/following::div[1]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>col-slot xs-up:w=100 lg-down:px=(1.25rem) lg-up:w=30 text-nowrap text-ellipsis d-lg-flex flex-lg-column lg-up:pl=0 lg-up:pr=4 lg-up:mt=(1.25rem)</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Cart SummaryMerchandise (Incl.VAT):AED 1,375.00 VAT Amount:  AED 55.65  Discount  AED 206.25  Order Total:  AED 1,168.75 or 4 interest-free payments of 292.19 AED. Learn more
            new TabbyPromo({
                selector: '#TabbyPromo',
                currency: 'AED',
                price: '1168.75',
                installmentsCount: 4,
                lang: 'en',
            });Apply a Promotion CodeRemove any spaces or dashes before hitting apply.Apply Checkout Now By continuing to Checkout, you are agreeing to our Terms of Use and Privacy Policy.</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;xs-up:bgc=body xs-up.fa-times:icon-before=cross state-loading&quot;]/div[@class=&quot;body&quot;]/div[@class=&quot;xs-up:fc=alpha xs-up:scrollable=none xs-up.icon:w=(1.875rem) xs-up.icon:h=(1.875rem) xs-up.icon:d=inblock xs-up.icon:stroke-width=(1.3867) md-up[leo-page]:px=4 lg-up[leo-page]:px=5 lg-up.LandingPage2Template>[leo-page]:px=0 xs-up.MultiStepCheckoutSummaryPageTemplate>[leo-page]:px=0 xs-up.MultiStepCheckoutSummaryPageTemplate+footer:d=none xs-up>>header>>[leo-page]:px=0 xs-up>>footer>>[leo-page]:px=0 md-up.ProductDetailsPageTemplate>[leo-page]:pr=0 xs-up>>picture:wmin=(1px) xs-up>>picture:hmin=(1px) xs-up>>picture:d=block&quot;]/cx-storefront[@class=&quot;stop-navigating&quot;]/cx-page-layout[@class=&quot;CartPageTemplate&quot;]/div[1]/div[@class=&quot;tpl-CartPageTemplate state-mega-menu-hidden xs-up:mb=4 xs-up:pos=rel&quot;]/div[@class=&quot;container lg-up:wmax=wide xl-up:wmax=(1300px)&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-slot xs-up:w=100 lg-down:px=(1.25rem) lg-up:w=30 text-nowrap text-ellipsis d-lg-flex flex-lg-column lg-up:pl=0 lg-up:pr=4 lg-up:mt=(1.25rem)&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Shopping is always safe and secure.'])[1]/following::div[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Secure Checkout'])[1]/following::div[3]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//cx-storefront/cx-page-layout/div/div/div/div/div[3]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = concat(&quot;Cart SummaryMerchandise (Incl.VAT):AED 1,375.00 VAT Amount:  AED 55.65  Discount  AED 206.25  Order Total:  AED 1,168.75 or 4 interest-free payments of 292.19 AED. Learn more
            new TabbyPromo({
                selector: &quot; , &quot;'&quot; , &quot;#TabbyPromo&quot; , &quot;'&quot; , &quot;,
                currency: &quot; , &quot;'&quot; , &quot;AED&quot; , &quot;'&quot; , &quot;,
                price: &quot; , &quot;'&quot; , &quot;1168.75&quot; , &quot;'&quot; , &quot;,
                installmentsCount: 4,
                lang: &quot; , &quot;'&quot; , &quot;en&quot; , &quot;'&quot; , &quot;,
            });Apply a Promotion CodeRemove any spaces or dashes before hitting apply.Apply Checkout Now By continuing to Checkout, you are agreeing to our Terms of Use and Privacy Policy.&quot;) or . = concat(&quot;Cart SummaryMerchandise (Incl.VAT):AED 1,375.00 VAT Amount:  AED 55.65  Discount  AED 206.25  Order Total:  AED 1,168.75 or 4 interest-free payments of 292.19 AED. Learn more
            new TabbyPromo({
                selector: &quot; , &quot;'&quot; , &quot;#TabbyPromo&quot; , &quot;'&quot; , &quot;,
                currency: &quot; , &quot;'&quot; , &quot;AED&quot; , &quot;'&quot; , &quot;,
                price: &quot; , &quot;'&quot; , &quot;1168.75&quot; , &quot;'&quot; , &quot;,
                installmentsCount: 4,
                lang: &quot; , &quot;'&quot; , &quot;en&quot; , &quot;'&quot; , &quot;,
            });Apply a Promotion CodeRemove any spaces or dashes before hitting apply.Apply Checkout Now By continuing to Checkout, you are agreeing to our Terms of Use and Privacy Policy.&quot;))]</value>
   </webElementXpaths>
</WebElementEntity>
