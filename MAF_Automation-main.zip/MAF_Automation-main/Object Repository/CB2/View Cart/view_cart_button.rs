<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>view_cart_button</name>
   <tag></tag>
   <elementGuidId>6d867372-2384-4a66-af00-a1e1bfc15829</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='Cb2UserMenuMiniCart']/div/div/div/a/i</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.user-menu-wrapper.state-mini.state-anonymous.state-not-empty > a.user-menu-link > i</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>i</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;Cb2UserMenuMiniCart&quot;)/div[@class=&quot;leo-mini-cart-component leo-mini-cart-component-user-menu-alpha-cart xs-up:pos=rel xs-up.user-menu-link:ml=3 md-up.user-menu-link:ml=4 xs-up.user-menu-link:txt-underline=no xs-up.user-menu-link:flx-row-align=center-center xs-up.user-menu-text:flx-row-align=center-center xs-up.user-menu-text:pr=2 xs-up.user-menu-link>[leo-icon]:pos=rel xs-up.user-menu-link>[leo-icon]:after:content=() xs-up.user-menu-link>[leo-icon]:after:bc=alpha xs-up.user-menu-link>[leo-icon]:after:bw-bottom=(0.25rem) xs-up.user-menu-link>[leo-icon]:after:pt=2 xs-up.user-menu-link>[leo-icon]:after:bottom=n2 xs-up.user-menu-link>[leo-icon]:after:d=none xs-up.user-menu-link>[leo-icon]:after:pos=abs xs-up.user-menu-link>[leo-icon]:after:right=0 xs-up.user-menu-link>[leo-icon]:after:w=100 xs-up.user-menu-dropdown:bgc=body xs-up.user-menu-dropdown:bc=light xs-up.user-menu-dropdown:bw=(1px) xs-up.user-menu-dropdown:pos=abs xs-up.user-menu-dropdown:p=4 xs-up.user-menu-dropdown:right=n4 xs-up.user-menu-dropdown:top=(2.375rem) xs-up.user-menu-dropdown:flx-dir=col xs-up.user-menu-dropdown:d=none xs-up.user-menu-dropdown:z=3 xs-up.user-menu-dropdown>[leo-dynamic]:mb=3 xs-up.user-menu-dropdown>ul:list-style=none xs-up.user-menu-dropdown>ul>li:not(:last-child):mb=2 xs-up.user-menu-dropdown>ul>li:fs=p4 xs-up.user-menu-dropdown>ul>li:fw=light xs-up.user-menu-dropdown>ul>li:txt-case=upper xs-up.user-menu-dropdown>ul>li:py=2 xs-up.user-menu-dropdown>ul>li:ls=.06 xs-up.user-menu-dropdown:before:content=() xs-up.user-menu-dropdown:before:pos=abs xs-up.user-menu-dropdown:before:top=n3 xs-up.user-menu-dropdown:before:leri=0 xs-up.user-menu-dropdown:before:h=(1rem) md-up&lt;:hover>>.user-menu-link>[leo-icon]:after:d=block md-up&lt;:hover>>.user-menu-dropdown:d=flx xs-up.headline:not(:last-child):mb=4 xs-up.headline:fc=beta xs-up.headline:fw=normal xs-up.content:not(:last-child):mb=2 xs-up.content>>a:txt-underline=yes xs-up.btn-cta:btn=alpha md-up.btn-cta:btn-size=medium xs-up.btn-cta:w=100 xs-up.btn-cta:not(:last-child):mb=2 xs-up>>svg.icon:pointer-events=disabled xs-up.user-menu-dropdown:fs=p4 xs-up.user-menu-dropdown:fw=light xs-up.user-menu-dropdown:p=5 xs-up.user-menu-dropdown:w=(25rem) xs-up.content:flx-order=1 xs-up.btn-cta:mb=3 xs-up.state-empty>>.user-menu-text:d=none xs-up.state-empty>>.headline:txt-case=upper xs-up.state-empty>>.headline:ls=.08 xs-up.products:mb=3 xs-up.product:mb=2 xs-up.user-menu-text:fs=p4 xs-up.user-menu-text:pos=abs xs-up.user-menu-text:top=(-1px) md-up.user-menu-text:top=(-4px) xs-up.user-menu-text:right=(4px) xs-up.user-menu-text:pr=0 xs-up.user-menu-text:w=(1.25rem) xs-up.user-menu-text:txt-align=center xs-up.state-page>>.btn-cta:d=none xs-up.user-menu-link:cursor=pointer xs-up.icon:w=(33px) xs-up.icon:h=(33px) user-menu-alpha-cart&quot;]/div[1]/div[@class=&quot;user-menu-wrapper state-mini state-anonymous state-not-empty&quot;]/a[@class=&quot;user-menu-link&quot;]/i[1]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='Cb2UserMenuMiniCart']/div/div/div/a/i</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sign in'])[2]/following::i[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sign in'])[1]/following::i[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Chelsea Home Office Chair'])[1]/preceding::i[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Qty: 1'])[1]/preceding::i[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/div/div/div/div/a/i</value>
   </webElementXpaths>
</WebElementEntity>
