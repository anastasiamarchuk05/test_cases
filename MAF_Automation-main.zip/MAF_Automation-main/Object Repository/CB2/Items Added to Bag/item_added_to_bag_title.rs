<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>item_added_to_bag_title</name>
   <tag></tag>
   <elementGuidId>d45c3f1f-0f7f-45ee-a844-a2366f609f61</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(//div[@id='undefined']/div/div/div/div/div/div/div)[2]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>cart-items-title xs-up:fs=p2 xs-up:pb=3 xs-up:bw-bottom=(1px) xs-up:bc=beta-60 xs-up:mb=4</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> Item(s) added to your bag </value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;xs-up:bgc=body xs-up.fa-times:icon-before=cross state-loading modal-open&quot;]/ngb-modal-window[@class=&quot;d-block fade modal modal-product-added-to-cart show xs-up:d=flx&quot;]/div[@class=&quot;modal-dialog modal-lg&quot;]/div[@class=&quot;modal-content&quot;]/div[1]/div[1]/div[@id=&quot;undefined&quot;]/div[@class=&quot;leo-cart-product-added-component leo-cart-product-added-component-leo-cart-product-added-component-default xs-up.add-to-cart:wmax=(1008px) xs-up.add-to-cart:mx=auto xs-up.add-to-cart:mb=3 lg-up.modal-body:px=0 lg-up.modal-body:pt=4 lg-up.modal-body:pb=2 md-up.modal-body:p=0 xs-up.modal-body>>.row:px=1 md-up.modal-body>>.row:px=3 md-up.modal-body>>.row:pt=3 xs-up.modal-body>>.col-md-7:px=0 md-up.modal-body>>.col-md-7:pr=(2rem) xs-up.modal-body>>.col-md-5:px=0 xs-up.modal-body>>.col-md-5:mb=2 xs-up.cart-items-title:d=flx xs-up.cart-items-title:flx-align-items=center xs-up.cart-items-title:bc=muted xs-up.cart-items-title:bw-bottom=(1px) xs-up.cart-items-title:mt=0 xs-up.cart-items-title:mb=4 xs-up.cart-items-title:flx-align-items=end xs-up.cart-items-title>>.icon-product-added:bgi=(assets/icons/icon-checkmark-success_gray.png) xs-up.cart-items-title>>.icon-product-added:bg-repeat=no xs-up.cart-items-title>>.icon-product-added:fw=light xs-up.cart-items-title>>.icon-product-added:wmin=(2.25rem) xs-up.cart-items-title>>.icon-product-added:hmin=(1.875rem) xs-up.product-info:fw=light! xs-up.product-info:fs=p4! xs-up.cart-items-title>>.close:pos=abs xs-up.cart-items-title>>.close:right=n1 xs-up.cart-items-title>>.close:top=0 xs-up.cart-items-title>>.close>>.fa-times:fs=h4 xs-up.cart-items-title>>.close>>.fa-times:fc=black xs-up.cart-items-title>>.close>>.fa-times:fw=light xs-up.cart-summary-title:bc=muted xs-up.cart-summary-title:lh=(28px) xs-up.cart-summary-title>>span:fs=p2 xs-up.cart-summary-title>>.close:pos=abs xs-up.cart-summary-title>>.close:right=(0.75rem) xs-up.cart-summary-title>>.close:top=(-2rem) xs-up.cart-summary-title>>.close>>.fa-times:fs=h4 xs-up.cart-summary-title>>.close>>.fa-times:fc=black xs-up.cart-summary-title>>.close>>.fa-times:fw=light xs-up.dialog-order-summary:mb=4 xs-up.dialog-order-summary:bc=muted xs-up.dialog-order-summary:fs=p4 xs-up.dialog-order-summary:fw=light xs-up.btn-continue-shopping:btn-outline=alpha xs-up.btn-continue-shopping:btn-size=medium xs-up.btn-continue-shopping:bw=(1px) xs-up.btn-continue-shopping:bc=alpha-60 xs-down.btn-continue-shopping:w=100! lg-up.btn-continue-shopping:w=(54%)! xs-up.btn-continue-shopping:hover:bgc=light xs-up.btn-continue-shopping:hover:fc=alpha lg-down.btn-continue-shopping:mb=2! md-up.btn-checkout-now:ml=2 xs-up.btn-checkout-now:btn=alpha xs-up.btn-checkout-now:btn-size=medium xs-down.btn-checkout-now:w=100! lg-up.btn-checkout-now:w=(43%)! sm-down.added-items:d=none sm-down.cart-summary-title:d=none sm-down.dialog-order-summary:d=none sm-down.add-to-cart:px=0 sm-down.add-to-cart:pt=(1.25rem) sm-down.add-to-cart:mt=3 xs-up.add-to-cart:mb=8 sm-down.add-to-cart>>.col-12:px=2 sm-down.cart-items-title:bw-bottom=0 sm-down.cart-items-title:mb=0 sm-down.cart-items-title:mt=2 sm-down.cart-items-title>>.close:top=(-3.5rem)! leo-cart-product-added-component-default default&quot;]/div[1]/div[@class=&quot;modal-body&quot;]/div[@class=&quot;container add-to-cart&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-12 col-lg-7 xs-up:mb=3&quot;]/div[@class=&quot;cart-items-title xs-up:fs=p2 xs-up:pb=3 xs-up:bw-bottom=(1px) xs-up:bc=beta-60 xs-up:mb=4&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>(//div[@id='undefined']/div/div/div/div/div/div/div)[2]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='View in AR'])[1]/following::div[12]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Got it!'])[2]/following::div[12]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Chelsea Home Office Chair'])[5]/preceding::div[3]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='AED 1,375.00'])[3]/preceding::div[4]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Item(s) added to your bag']/parent::*</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//ngb-modal-window/div/div/div/div/div/div/div/div/div/div/div/div</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = ' Item(s) added to your bag ' or . = ' Item(s) added to your bag ')]</value>
   </webElementXpaths>
</WebElementEntity>
