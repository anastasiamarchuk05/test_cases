<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>sign_in_register_button</name>
   <tag></tag>
   <elementGuidId>ff758fbe-4fa8-4a6d-8301-848762cbec85</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='Cb2UserMenuMiniAccount']/div/div/div/a/i</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>a.user-menu-link > i</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>i</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;Cb2UserMenuMiniAccount&quot;)/div[@class=&quot;leo-account-drop-down-component leo-account-drop-down-component-user-menu-alpha-account xs-up:pos=rel xs-up.user-menu-link:ml=3 md-up.user-menu-link:ml=4 xs-up.user-menu-link:txt-underline=no xs-up.user-menu-link:flx-row-align=center-center xs-up.user-menu-text:flx-row-align=center-center xs-up.user-menu-text:pr=2 xs-up.user-menu-link>[leo-icon]:pos=rel xs-up.user-menu-link>[leo-icon]:after:content=() xs-up.user-menu-link>[leo-icon]:after:bc=alpha xs-up.user-menu-link>[leo-icon]:after:bw-bottom=(0.25rem) xs-up.user-menu-link>[leo-icon]:after:pt=2 xs-up.user-menu-link>[leo-icon]:after:bottom=n2 xs-up.user-menu-link>[leo-icon]:after:d=none xs-up.user-menu-link>[leo-icon]:after:pos=abs xs-up.user-menu-link>[leo-icon]:after:right=0 xs-up.user-menu-link>[leo-icon]:after:w=100 xs-up.user-menu-dropdown:bgc=body xs-up.user-menu-dropdown:bc=light xs-up.user-menu-dropdown:bw=(1px) xs-up.user-menu-dropdown:pos=abs xs-up.user-menu-dropdown:p=4 xs-up.user-menu-dropdown:right=n4 xs-up.user-menu-dropdown:top=(2.375rem) xs-up.user-menu-dropdown:flx-dir=col xs-up.user-menu-dropdown:d=none xs-up.user-menu-dropdown:z=3 xs-up.user-menu-dropdown>[leo-dynamic]:mb=3 xs-up.user-menu-dropdown>ul:list-style=none xs-up.user-menu-dropdown>ul>li:not(:last-child):mb=2 xs-up.user-menu-dropdown>ul>li:fs=p4 xs-up.user-menu-dropdown>ul>li:fw=light xs-up.user-menu-dropdown>ul>li:txt-case=upper xs-up.user-menu-dropdown>ul>li:py=2 xs-up.user-menu-dropdown>ul>li:ls=.06 xs-up.user-menu-dropdown:before:content=() xs-up.user-menu-dropdown:before:pos=abs xs-up.user-menu-dropdown:before:top=n3 xs-up.user-menu-dropdown:before:leri=0 xs-up.user-menu-dropdown:before:h=(1rem) md-up&lt;:hover>>.user-menu-link>[leo-icon]:after:d=block md-up&lt;:hover>>.user-menu-dropdown:d=flx xs-up.headline:not(:last-child):mb=4 xs-up.headline:fc=beta xs-up.headline:fw=normal xs-up.content:not(:last-child):mb=2 xs-up.content>>a:txt-underline=yes xs-up.btn-cta:btn=alpha md-up.btn-cta:btn-size=medium xs-up.btn-cta:w=100 xs-up.btn-cta:not(:last-child):mb=2 xs-up>>svg.icon:pointer-events=disabled xs-up.user-menu-text:d=none xs-up.user-menu-dropdown:w=(12.5rem) xs-up.user-menu-dropdown-title:txt-case=upper xs-up.user-menu-dropdown-title:pb=2 xs-up.user-menu-dropdown-title:ls=.06 user-menu-alpha-account&quot;]/div[1]/div[@class=&quot;user-menu-wrapper state-anonymous&quot;]/a[@class=&quot;user-menu-link&quot;]/i[1]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='Cb2UserMenuMiniAccount']/div/div/div/a/i</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Search'])[1]/following::i[3]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='CB2'])[1]/following::i[3]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sign In / Register'])[1]/preceding::i[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Order Tracking'])[1]/preceding::i[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//a/i</value>
   </webElementXpaths>
</WebElementEntity>
