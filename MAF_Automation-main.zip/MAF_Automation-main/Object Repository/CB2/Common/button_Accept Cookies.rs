<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_Accept Cookies</name>
   <tag></tag>
   <elementGuidId>bdf06b5c-bb7c-44e9-b209-1ab508d91290</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='Cb2AnonymousConsentManagementBannerComponent']/div/div/div/div/div/div/div/button[2]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>button.btn-cookie-warning-accept</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>button</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>btn-cookie-warning-accept</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> Accept Cookies </value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;Cb2AnonymousConsentManagementBannerComponent&quot;)/div[@class=&quot;leo-advanced-responsive-banner-component leo-advanced-responsive-banner-component-cookie-warning-alpha xs-up.cookie-warning-container:bw-top=(1px) xs-up.cookie-warning-container:bc=light xs-up.cookie-warning-container:fs=p3 xs-up.cookie-warning-container:fc=alpha xs-up.cookie-warning-container:py=4 xs-up.cookie-warning-container:hmax=(50%) xs-up.cookie-warning-container:scrollable=y xs-up.cookie-warning-container:z=99 xs-up.cookie-warning-container:pos=fix xs-up.cookie-warning-container:bottom=0 xs-up.cookie-warning-container:left=0 xs-up.cookie-warning-container:right=0 xs-up.cookie-warning-container>>.container:wmax=100 xl-up.cookie-warning-container>>.container:wmax=vast md-up.cookie-warning-container>>.container:px=4 xl-up.cookie-warning-container>>.container:px=(3rem) lg-up.cookie-warning-banner:flx-row-align=center-between xs-up.cookie-warning-banner>>button:d=inblock xs-up.cookie-warning-banner>>button:not(:first-child):ml=3 xs-up.cookie-warning-banner>>button:first-child:ml=auto xs-up.cookie-warning-banner>>.headline:fc=alpha xs-up.cookie-warning-banner>>.headline:fw=light! xs-up.cookie-warning-banner>>.headline:fh=6 xs-up.cookie-warning-banner>>.content:txt-case=none xs-up.cookie-warning-banner>>.content:fw=light lg-up.cookie-warning-banner>>.content:pr=5 lg-up.cookie-warning-banner>>.content>>p:last-child:mb=0 xs-up.btn-cookie-warning-details:btn-outline=alpha md-down.btn-cookie-warning-details:ml=0! xs-up.btn-cookie-warning-accept:btn=alpha cookie-warning-alpha&quot;]/div[1]/div[@class=&quot;cookie-warning-container&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-12&quot;]/div[@class=&quot;cookie-warning-banner&quot;]/button[@class=&quot;btn-cookie-warning-accept&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='Cb2AnonymousConsentManagementBannerComponent']/div/div/div/div/div/div/div/button[2]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='View Details'])[1]/following::button[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Your Cookie Settings'])[1]/following::button[2]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Capture object:'])[1]/preceding::button[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Alt'])[1]/preceding::button[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Accept Cookies']/parent::*</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div/div/div/div/div/div/button[2]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//button[(text() = ' Accept Cookies ' or . = ' Accept Cookies ')]</value>
   </webElementXpaths>
</WebElementEntity>
