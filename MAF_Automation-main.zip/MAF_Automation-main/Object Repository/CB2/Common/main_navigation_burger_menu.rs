<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>main_navigation_burger_menu</name>
   <tag></tag>
   <elementGuidId>fb96f7ae-72a2-4d6e-ae20-45cbaeda16c3</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='Cb2LinkMegaMenuDesktop']/div/div/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>a.link.state-active</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>role</name>
      <type>Main</type>
      <value>button</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>link state-active</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-content</name>
      <type>Main</type>
      <value>
              &lt;svg class=&quot;icon icon-active xs-up:stroke=currentColor&quot;>
                &lt;use xlink:href=&quot;assets/icon.svg#svg-icon-close&quot;>&lt;/use>
              &lt;/svg>
            
            &lt;svg class=&quot;icon icon-passive xs-up:stroke=currentColor&quot;>
              &lt;use xlink:href=&quot;assets/icon.svg#svg-icon-menu&quot;>&lt;/use>
            &lt;/svg>
            &lt;span>&lt;/span>
          </value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;Cb2LinkMegaMenuDesktop&quot;)/div[@class=&quot;leo-link-component leo-link-component-nav-hamburger-desktop md-up:mr=4 sm-down:mr=(1.175rem) xs-up.icon:stroke-width=(1.674) xs-up.icon:h=(1.674rem) xs-up.icon:w=(1.813rem) xs-up.icon-active:d=none sm-down.icon-passive:h=(1.5rem) sm-down.icon-passive:w=(1.563rem) sm-down.icon-passive:stroke-width=(3px) sm-down.icon-passive:ml=1 sm-down.icon-active:stroke-width=(2.5) xs-up&lt;&lt;.state-mega-menu-open>>.icon-active:d=block xs-up&lt;&lt;.state-mega-menu-open>>.icon-passive:d=none xs-up.link:d=flx xs-up>>svg.icon:pointer-events=disabled xs-up&lt;&lt;.tpl-CategoryPageLevel1Template:d=none xs-up&lt;&lt;.tpl-CategoryPageLevel2Template:d=none xs-up&lt;&lt;.tpl-CategoryPageTemplate:d=none xs-up&lt;&lt;.tpl-ProductListPageTemplate:d=none xs-up&lt;&lt;.tpl-SearchResultsListPageTemplate:d=none xs-up:none lg-up:nav-hamburger-desktop&quot;]/div[1]/a[@class=&quot;link state-active&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='Cb2LinkMegaMenuDesktop']/div/div/a</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='CB2'])[1]/following::a[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Search'])[1]/preceding::a[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sign In / Register'])[1]/preceding::a[3]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//a</value>
   </webElementXpaths>
</WebElementEntity>
