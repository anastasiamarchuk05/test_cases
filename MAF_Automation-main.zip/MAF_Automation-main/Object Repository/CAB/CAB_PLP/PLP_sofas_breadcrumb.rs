<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>This object defines breadcrumb at sofa plp</description>
   <name>PLP_sofas_breadcrumb</name>
   <tag></tag>
   <elementGuidId>7f96288f-7612-40ec-8ea6-f45838d5a2c0</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;breadcrumbComponent&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
