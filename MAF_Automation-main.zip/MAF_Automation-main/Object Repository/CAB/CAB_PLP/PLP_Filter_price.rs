<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>This object defines &quot;price&quot; component under filter option</description>
   <name>PLP_Filter_price</name>
   <tag></tag>
   <elementGuidId>6bd4631b-e82e-4bb9-9444-648c022ba4a6</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;RefinementFacetComponent&quot;]/div/div/div/div[3]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
