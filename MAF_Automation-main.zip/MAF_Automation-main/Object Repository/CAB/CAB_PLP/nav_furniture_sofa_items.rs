<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>this object defines sofas under the &quot;furniture&quot; items</description>
   <name>nav_furniture_sofa_items</name>
   <tag></tag>
   <elementGuidId>de8c76f8-ed51-469f-bde8-678a520568e2</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;CabCategoryNavComponent&quot;]/div/div/ul/li[2]/div[2]/ul[1]/li/div[1]/div[2]/ul[1]/li/div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
