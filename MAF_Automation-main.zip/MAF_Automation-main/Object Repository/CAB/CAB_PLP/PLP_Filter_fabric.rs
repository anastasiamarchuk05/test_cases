<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>This object defines &quot;Fabric&quot; component under filter option</description>
   <name>PLP_Filter_fabric</name>
   <tag></tag>
   <elementGuidId>3e844876-83a1-4913-a7bc-55d3f20ab90b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;RefinementFacetComponent&quot;]/div/div/div/div[6]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
