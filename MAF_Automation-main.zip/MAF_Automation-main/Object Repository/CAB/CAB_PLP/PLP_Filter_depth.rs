<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>This object defines &quot;Depth&quot; componenet under filter option</description>
   <name>PLP_Filter_depth</name>
   <tag></tag>
   <elementGuidId>47d0ef72-c7f6-4440-b6fa-91d387428f43</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;RefinementFacetComponent&quot;]/div/div/div/div[4]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
