<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>This object defines &quot;Furniture&quot; item on the navigation list on the homepage</description>
   <name>nav_Furniture</name>
   <tag></tag>
   <elementGuidId>f8c6e629-a437-4a0f-a82b-eed95b74d91d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;CabCategoryNavComponent&quot;]/div/div/ul/li[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
