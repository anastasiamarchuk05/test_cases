<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>This object defines ordering items by lowest price at sofa plp</description>
   <name>PLP_relevance_price_low</name>
   <tag></tag>
   <elementGuidId>d83c6c80-9ed0-43d4-b4b3-630f1ff32060</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;CabFlexSort&quot;]/div/div/div[2]/div/button[5]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
