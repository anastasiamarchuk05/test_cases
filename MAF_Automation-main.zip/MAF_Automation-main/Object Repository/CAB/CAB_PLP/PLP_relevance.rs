<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>This object defines &quot;relevance&quot; cta at sofa plp</description>
   <name>PLP_relevance</name>
   <tag></tag>
   <elementGuidId>8589c4ad-af36-4bef-a2ee-4429ca4fca73</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;sort&quot;]/text()</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
