<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>This object defines ordering items ascending by names at sofa plp</description>
   <name>PLP_relevance_ascending</name>
   <tag></tag>
   <elementGuidId>a6a80764-d43b-434e-b24a-be96cd3582ed</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;CabFlexSort&quot;]/div/div/div[2]/div/button[3]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
