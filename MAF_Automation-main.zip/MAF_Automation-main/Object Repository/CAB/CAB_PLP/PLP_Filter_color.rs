<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>This object defines &quot;Color&quot; component under filter option</description>
   <name>PLP_Filter_color</name>
   <tag></tag>
   <elementGuidId>8b1ded3d-69b4-4543-ab0e-7c0bc850b6c4</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;RefinementFacetComponent&quot;]/div/div/div/div[5]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
