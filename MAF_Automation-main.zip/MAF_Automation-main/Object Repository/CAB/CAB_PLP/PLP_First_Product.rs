<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>This object defines first item at sofa plp</description>
   <name>PLP_First_Product</name>
   <tag></tag>
   <elementGuidId>e9712e43-78f1-4fcc-877e-262888afa1b7</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;ProductListComponent&quot;]/div/div/div/div[1]/div[1]/div[1]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
