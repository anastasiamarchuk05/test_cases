<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>This object defines &quot;sofas&quot; title at Sofas plp</description>
   <name>PLP_sofas_title</name>
   <tag></tag>
   <elementGuidId>2dd43c26-d1d6-4720-8157-816327d6565a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;CabParagraphCategory-sofas&quot;]/div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
