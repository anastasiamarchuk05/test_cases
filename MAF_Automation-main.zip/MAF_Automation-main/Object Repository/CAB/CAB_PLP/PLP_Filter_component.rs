<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>This object defines &quot;Filter&quot; component at &quot;Sofas&quot; PLP</description>
   <name>PLP_Filter_component</name>
   <tag></tag>
   <elementGuidId>3105094d-0943-460a-b486-8068118686b6</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;CabFlexToggleFilters&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
