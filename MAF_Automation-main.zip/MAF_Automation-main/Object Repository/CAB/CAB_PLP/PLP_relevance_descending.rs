<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>This object defines ordering items descending by names at sofa plp</description>
   <name>PLP_relevance_descending</name>
   <tag></tag>
   <elementGuidId>b7f0056c-1325-4be0-aa4c-774e0f621893</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;CabFlexSort&quot;]/div/div/div[2]/div/button[4]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
