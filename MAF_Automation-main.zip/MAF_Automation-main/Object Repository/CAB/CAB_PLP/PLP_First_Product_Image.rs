<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>This object defines product image for first item on the sofa page</description>
   <name>PLP_First_Product_Image</name>
   <tag></tag>
   <elementGuidId>1172437a-b24b-4681-ac19-14b9b6b634bb</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;undefined&quot;]/div/div/a/div/div/picture/img</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
