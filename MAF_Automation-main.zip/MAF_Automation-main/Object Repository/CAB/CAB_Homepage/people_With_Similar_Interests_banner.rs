<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>This object defines &quot;People With Similar Interests Also Bought&quot; banner</description>
   <name>people_With_Similar_Interests_banner</name>
   <tag></tag>
   <elementGuidId>a3605488-14b2-4d7e-b47d-cf3b996dd546</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;CabAdvancedGridAlgonomyHompageRank3&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
