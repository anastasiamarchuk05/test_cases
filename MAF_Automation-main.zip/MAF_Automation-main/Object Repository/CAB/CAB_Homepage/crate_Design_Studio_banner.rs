<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>This object defines &quot;Crate Design Studio&quot; banner</description>
   <name>crate_Design_Studio_banner</name>
   <tag></tag>
   <elementGuidId>af7f9509-b92b-4787-a457-e1ac1299527a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;CabAdvancedGridComponentBannerAlpha1&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
