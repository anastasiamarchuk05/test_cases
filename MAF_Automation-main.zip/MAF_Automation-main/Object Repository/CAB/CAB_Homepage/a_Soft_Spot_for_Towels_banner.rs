<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>This object defines &quot; a soft spot for towels&quot; banner</description>
   <name>a_Soft_Spot_for_Towels_banner</name>
   <tag></tag>
   <elementGuidId>fc6d74d9-8584-4168-a5ee-5231e946cccb</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;comp_00238288&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
