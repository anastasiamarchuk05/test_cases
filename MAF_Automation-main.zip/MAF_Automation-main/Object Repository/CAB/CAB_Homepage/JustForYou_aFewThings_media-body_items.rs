<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>This object defines those items where listed under &quot;Just for you a few things we think you'll love&quot;</description>
   <name>JustForYou_aFewThings_media-body_items</name>
   <tag></tag>
   <elementGuidId>7976d0d6-a4a7-45fa-9bab-4c497b5a2742</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;comp_00385285&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
