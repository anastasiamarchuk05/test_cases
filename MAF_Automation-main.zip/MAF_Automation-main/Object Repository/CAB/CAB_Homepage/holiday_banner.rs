<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>this object defines the banner top of the page at homapage</description>
   <name>holiday_banner</name>
   <tag></tag>
   <elementGuidId>cf7312a5-f48d-4092-8faf-0aa8ac6b98bd</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;comp_00390344&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
