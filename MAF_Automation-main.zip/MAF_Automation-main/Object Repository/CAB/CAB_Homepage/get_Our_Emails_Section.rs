<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>This onject defines &quot;Find out first. Get our emails for info on new items, sales and more.&quot;</description>
   <name>get_Our_Emails_Section</name>
   <tag></tag>
   <elementGuidId>11bffed0-09b6-461d-b907-5cbbf21f8a76</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;CabAdvancedGridNewsletterSignupV2&quot;]/div</value>
      </entry>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
