<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>This object defines &quot;Top products houseware&quot; carousel from algonomy</description>
   <name>top_Product_Housewares_carousel</name>
   <tag></tag>
   <elementGuidId>f503d195-dbed-48ac-b569-2aab7423a0bb</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;CabAdvancedGridAlgonomyHompageRank3&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
