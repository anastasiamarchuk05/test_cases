<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>This object defines &quot;the holidays are coming - peek our collection here&quot; media body</description>
   <name>theHolidaysAreComing_media-body</name>
   <tag></tag>
   <elementGuidId>59e77b0f-085d-4629-9ecc-fb975620f600</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;comp_00390333&quot;]/div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
