<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>This object defines the banner for &quot;work form home essentials&quot;</description>
   <name>work_From_Home_Essentials_banner</name>
   <tag></tag>
   <elementGuidId>14e4f7f7-fc78-4430-aef0-9048d56d7086</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;comp_00385229&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
