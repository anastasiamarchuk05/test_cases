<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>This object defines &quot;Order Tracking &amp; Schedule Delivery&quot; cart at bottom of the page</description>
   <name>order_Tracking_Schedule_Delivery_card</name>
   <tag></tag>
   <elementGuidId>d0cb4aef-7d31-4d1a-b739-3712ace08ac0</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;CabCardOrderTrackingV2&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
