<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>This object defines &quot;It's your favorite everyday getaway&quot; banner</description>
   <name>it_Your_Favorite_Everyday_Getaway</name>
   <tag></tag>
   <elementGuidId>70e7be61-d0a0-40a2-b1d1-ee1ac89f792e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;comp_00198008&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
