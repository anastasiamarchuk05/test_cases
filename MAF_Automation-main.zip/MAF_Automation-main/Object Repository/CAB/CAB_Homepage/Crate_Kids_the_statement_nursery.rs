<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>This object defines &quot;Crate and Kids&quot; the statement nursery banner</description>
   <name>Crate_Kids_the_statement_nursery</name>
   <tag></tag>
   <elementGuidId>6c362598-d087-42e4-bec0-7821d962ae01</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;comp_00225024&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
