<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>This object defines &quot;Basics that make the bed&quot; banner</description>
   <name>basics_that_make_theBed_Banner</name>
   <tag></tag>
   <elementGuidId>c767e362-9def-4e75-831c-167ccac890a0</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;comp_00238286&quot;]/div/div/div/div/div/div[2]/div[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
