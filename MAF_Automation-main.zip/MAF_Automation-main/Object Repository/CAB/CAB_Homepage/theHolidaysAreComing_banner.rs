<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>This object defines &quot;the holiday is coming &quot; banner</description>
   <name>theHolidaysAreComing_banner</name>
   <tag></tag>
   <elementGuidId>96b4ee15-bc9c-4bdf-8641-dc945b68278e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;comp_00390331&quot;]/div/div/div/div/div/div[2]/div[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
