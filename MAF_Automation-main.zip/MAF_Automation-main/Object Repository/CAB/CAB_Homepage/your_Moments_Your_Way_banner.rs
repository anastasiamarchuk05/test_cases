<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>This object defines &quot;Your moments your way&quot; banner</description>
   <name>your_Moments_Your_Way_banner</name>
   <tag></tag>
   <elementGuidId>8b50c8ff-b40e-44ef-b8b9-f952c4c43b19</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;CabAdvancedGridComponentBeta&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
