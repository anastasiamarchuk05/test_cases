<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>This object defines &quot;You previously viewed&quot; banner</description>
   <name>previously_viewed_products_banner</name>
   <tag></tag>
   <elementGuidId>247a7e3a-2c34-4cb6-900f-1291ff787344</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;CabAdvancedGridAlgonomyHompageHistoryLine&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
