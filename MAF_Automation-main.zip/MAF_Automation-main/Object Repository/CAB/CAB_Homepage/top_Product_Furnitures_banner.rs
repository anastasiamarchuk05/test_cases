<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>This object defines the banner for &quot;Top product furnitures&quot;</description>
   <name>top_Product_Furnitures_banner</name>
   <tag></tag>
   <elementGuidId>45fba905-bfe1-470c-a6f6-d0d38c602388</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;CabAdvancedGridAlgonomyHompageRank2&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
