<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>This object defines &quot;Contact Us&quot; card bottum of the page</description>
   <name>contact_Us_card</name>
   <tag></tag>
   <elementGuidId>41300132-4d89-4f5b-9990-86238b9376a8</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;CabCardContactUs&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
