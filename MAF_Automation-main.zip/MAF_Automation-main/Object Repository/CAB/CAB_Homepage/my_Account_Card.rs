<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>This object defines my account card at bottom of the page</description>
   <name>my_Account_Card</name>
   <tag></tag>
   <elementGuidId>f50e376c-d847-4fba-b47d-d34e4fe591d1</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;CabAdvancedGridFooterCardsComponentV2&quot;]/div/div/div/div/div/div[2]/div[2]</value>
      </entry>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
