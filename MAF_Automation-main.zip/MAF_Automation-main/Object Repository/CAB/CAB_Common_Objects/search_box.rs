<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>This object defines the serach box at homepage</description>
   <name>search_box</name>
   <tag></tag>
   <elementGuidId>26bfb1b3-3e1b-4806-a6ff-80b23f5f91d8</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;SearchBox&quot;]/div/div/div/div
</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
