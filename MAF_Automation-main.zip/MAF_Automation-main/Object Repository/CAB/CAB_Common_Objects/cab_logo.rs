<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>cab logo top of the page(center)</description>
   <name>cab_logo</name>
   <tag></tag>
   <elementGuidId>64bfbaba-a24e-48f3-8d28-61c925f1b150</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;SiteLogoComponent&quot;]/div/div/a/span/div/picture/img
</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
