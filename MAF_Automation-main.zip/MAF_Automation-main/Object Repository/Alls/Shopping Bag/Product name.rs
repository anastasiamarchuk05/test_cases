<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Product name</name>
   <tag></tag>
   <elementGuidId>d8cce9aa-4293-48ba-9cd6-4320817d7216</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='undefined']/div/div/div/table/tbody/tr/td[2]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>td.table-cell-name > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/en-ae/product/caylan-harris-dress/UPV0891446</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> Caylan Harris Dress </value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;CartDetails&quot;)/div[@class=&quot;leo-cart-component leo-cart-component-cart-details xs-up:cart-details-total:d=none xs-up:total-amount:txt-align=right xs-up:total-tax-label:fs=p3 xs-up:total-tax-label:fw=normal xs-up:total-tax-label:fc=beta-70 xs-up:btn-checkout:my=3 xs-up.cx-promotions>ul:p=0 xs-up.cx-promotions>ul:list-style=none xs-up.cx-promotions>ul>li:p=2 xs-up.cx-promotions>ul>li:my=2 xs-up.cx-promotions>ul>li:bgc=light xs-up.cx-promotions>ul>li:fc=danger xs-up:cart-list:d=flx xs-up:cart-list:flx-dir=col xs-up:cart-list:mt=4 xs-up:cart-item-top-container:w=100 xs-up:cart-item-top-container:d=flx xs-up:cart-item-top-container:flx-wrap=yes xs-up:cart-item-top-container:p=3 xs-up:cart-item-top-container:pb=1 md-up:cart-item-top-container:bw-bottom=(2px) md-up:cart-item-top-container:bc=light xs-up:cart-item-product-info:pb=3 xs-up:cart-item-product-info:w=100 md-up:cart-item-product-info:w=50 xs-up:cart-item-price-wrapper:w=100 md-up:cart-item-price-wrapper:w=50 xs-up:cart-item-price-wrapper:bw-bottom=(2px) xs-up:cart-item-price-wrapper:bw-top=(2px) xs-up:cart-item-price-wrapper:bc=light md-up:cart-item-price-wrapper:bw=0 xs-up:cart-item-price-wrapper:d=flx xs-up:cart-item-price-wrapper:flx-dir=row xs-up:cart-item-price-wrapper:flx-row-align=top-between xs-up:cart-item-price-wrapper:pt=3 xs-up:cart-item-price-wrapper:pb=2 md-up:cart-item-price-wrapper:pt=0 xs-up:cart-item-price-form-wrapper:d=flx xs-up:cart-item-price-form-wrapper:flx-dir=row xs-up:cart-item-price-form:d=flx xs-up:cart-item-price-form:flx-dir=col xs-up:cart-item-quantity-input:mb=0 xs-up:cart-item-quantity-input:w=(3.75rem) xs-up:cart-item-quantity-input:txt-align=center xs-up:cart-item-quantity-input:fs=p2 md-up:cart-item-quantity-input:fs=p3 xs-up:cart-item-quantity-update:px=2 xs-up:cart-item-quantity-update:fc=link xs-up:cart-item-bottom-container:py=3 xs-up:cart-item-bottom-container:w=100 xs-up:cart-item-bottom-container:d=flx xs-up:cart-item-bottom-container:flx-wrap=yes xs-up:cart-item-product-image:w=50 md-up:cart-item-product-image:w=30 lg-up:cart-item-product-image:w=20 xs-up:cart-item-shipment-container:w=50 lg-up:cart-item-shipment-container:w=60 xs-up:cart-item-item-actions:w=100 md-up:cart-item-item-actions:w=20 xs-up:cart-item-item-actions:d=flx xs-up:cart-item-item-actions:pt=3 md-up:cart-item-item-actions:pt=0 xs-up:cart-item-item-actions:flx-wrap=yes xs-up:cart-item-btn-remove:flx-align-items=center xs-up:cart-item-btn-remove:flx-justify-content=center xs-up:cart-item-btn-remove:bc=light xs-up:cart-item-btn-remove:bw=0 xs-up:cart-item-btn-remove:bw-right=(1px) xs-up:cart-item-btn-remove:bw-bottom=(2px) xs-up:cart-item-btn-remove:bw-top=(2px) md-up:cart-item-btn-remove:bw=0 md-up:cart-item-btn-remove:bw-left=(2px) md-up:cart-item-btn-remove:bw-bottom=(1px) xs-up:cart-item-btn-remove:py=3 md-up:cart-item-btn-remove:py=4 xs-up:cart-item-btn-remove:d=flx xs-up:cart-item-btn-remove:flx-dir=row md-up:cart-item-btn-remove:flx-dir=col md-up:cart-item-btn-remove:bgc=danger xs-up:cart-item-btn-remove:w=50 md-up:cart-item-btn-remove:w=100 xs-up.button-remove:icon-before=remove xs-up:cart-item-btn-remove-text:m=auto xs-up:cart-item-btn-remove-text:mt=2 xs-up:cart-item-btn-remove-text:ml=3 md-up:cart-item-btn-remove-text:mx=auto xs-up:cart-item-btn-add-to-wishlist:bc=light xs-up:cart-item-btn-add-to-wishlist:bw=0 xs-up:cart-item-btn-add-to-wishlist:bw-left=(1px) xs-up:cart-item-btn-add-to-wishlist:bw-top=(2px) xs-up:cart-item-btn-add-to-wishlist:bw-bottom=(2px) md-up:cart-item-btn-add-to-wishlist:bw=0 md-up:cart-item-btn-add-to-wishlist:bw-left=(2px) md-up:cart-item-btn-add-to-wishlist:bw-top=(1px) xs-up:cart-item-btn-add-to-wishlist:flx-align-items=center xs-up:cart-item-btn-add-to-wishlist:flx-justify-content=center xs-up:cart-item-btn-add-to-wishlist:py=3 md-up:cart-item-btn-add-to-wishlist:py=4 xs-up:cart-item-btn-add-to-wishlist:d=flx xs-up:cart-item-btn-add-to-wishlist:flx-dir=row md-up:cart-item-btn-add-to-wishlist:flx-dir=col xs-up:cart-item-btn-add-to-wishlist:w=50 md-up:cart-item-btn-add-to-wishlist:w=100 xs-up.button-save-for-later:icon-before=save-for-later xs-up:cart-item-btn-add-to-wishlist-text:m=auto xs-up:cart-item-btn-add-to-wishlist-text:mt=2 xs-up:cart-item-btn-add-to-wishlist-text:ml=3 md-up:cart-item-btn-add-to-wishlist-text:ml=auto xs-up.tooltip-inner:wmax=(6rem) md-up.tooltip-inner:wmax=(9rem) cart-details&quot;]/div[1]/div[@class=&quot;cart-details-wrapper&quot;]/div[2]/div[@id=&quot;undefined&quot;]/div[@class=&quot;leo-cart-items-list-component leo-cart-items-list-component-cart-list-alpha xs-up:mb=3 xs-up:ls=.1 xs-up:txt-shadow=(0|0|#000) xs-up.back-to-shop-wrapper:mb=7 xs-up.back-to-shop-wrapper:pl=3 xs-up.back-to-shop-link:fs=p2 xs-up.back-to-shop-link:mb=p2 xs-up.back-to-shop-link:hover:txt-underline=no xs-up.item-list-table:txt-align=center xs-up.item-list-table:bgc=(#ddd) xs-up.item-list-table:px=(10px) xs-up.item-list-table:w=100 xs-up.item-list-table:border-collapse=separate xs-up.item-list-table:border-spacing=(0|10px) sm-down.item-list-table:mb=4 xs-up>>th:txt-case=upper xs-up>>th:fw=regular xs-up>>th:first-child:txt-align=left xs-up>>th:first-child:pl=(5rem) xs-up>>th.table-header-item:d=tcell md-up>>th.table-header-item:d=none xs-up>>th.table-header-item-colspan:d=none md-up>>th.table-header-item-colspan:d=tcell xs-up>>th.table-header-colour:d=none md-up>>th.table-header-colour:d=tcell xs-up>>th.table-header-name:d=none md-up>>th.table-header-name:d=tcell xs-up>>th.table-header-size:d=none md-up>>th.table-header-size:d=tcell xs-up>>th.table-header-total-price:d=none xs-up>>td:p=0 xs-up>>td:bgc=white xs-up>>td:first-child:w=(100px) xs-up>>td:first-child:txt-align=left xs-up>>td:last-child:v-align=top xs-up>>td:last-child:w=(35px) xs-up>>td.table-cell-color:d=none md-up>>td.table-cell-color:d=tcell xs-up>>td.table-cell-name:w=30 xs-up>>td.table-cell-name:txt-align=center xs-up>>td.table-cell-name:txt-case=upper xs-up>>td.table-cell-name:ls=.2 xs-up>>td.table-cell-name:d=none md-up>>td.table-cell-name:d=tcell xs-up>>td.table-cell-size:d=none md-up>>td.table-cell-size:d=tcell xs-up>>td.table-cell-price:d=none xs-up.table-cell-name>>a:hover:txt-underline=no xs-up>>img:w=(100px) xs-up.media-placeholder:pt=(116%) xs-up.variant-item-container:pointer-events=disabled xs-up.variant-list-item:mr=0! xs-up.variant-item:flx-align-items=center! xs-up.variant-item:cursor=default xs-up.variant-item:pr=0! xs-up.variant-item>>[leo-media]:mb=2 xs-up.variant-item>>.tooltip:d=none! xs-up.variant-value:bw-bottom=0! xs-up.item-quantity:d=block xs-up.item-quantity:w=(3rem) xs-up.item-quantity:lh=2 xs-up.decrease:icon-before=minus xs-up.increase:icon-before=plus xs-up.qty:fs=p3 xs-up.qty:fw=bold xs-up.qty:p=0 xs-up.qty:square=(2.083rem) xs-up.qty-buttons:d=flx xs-up.qty-buttons:flx-justify-content=center xs-up.qty-buttons>.qty:d=flx xs-up.qty-buttons>.qty:flx-row-align=center-center xs-up.qty-buttons>.qty:before:d=block xs-up.size-inside-quantity:d=inblock xs-up.size-inside-quantity:mt=3 md-up.size-inside-quantity:d=none xs-up.button-remove:icon-before=remove xs-up.button-remove:before:w=(1.4rem) xs-up.empty-cell:txt-align=center! xs-up.empty-cell:bgc=transparent xs-up>>td.empty-cell:p=7 cart-list-alpha&quot;]/div[1]/div[@class=&quot;leo-item-list&quot;]/table[@class=&quot;item-list-table&quot;]/tbody[1]/tr[1]/td[@class=&quot;table-cell-name&quot;]/a[1]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='undefined']/div/div/div/table/tbody/tr/td[2]/a</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Caylan Harris Dress')]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Total Price'])[1]/following::a[2]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Price'])[1]/following::a[2]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Selected option is no longer available.'])[1]/preceding::a[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Caylan Harris Dress']/parent::*</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>(//a[contains(@href, '/en-ae/product/caylan-harris-dress/UPV0891446')])[2]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//td[2]/a</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/en-ae/product/caylan-harris-dress/UPV0891446' and (text() = ' Caylan Harris Dress ' or . = ' Caylan Harris Dress ')]</value>
   </webElementXpaths>
</WebElementEntity>
