<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_You could earn 87 SHARE</name>
   <tag></tag>
   <elementGuidId>b205e5ea-260a-4eae-a66a-67db0046f367</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='undefined']/div/div/div/div/div[2]/span</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>welcome-text xs-up:fw=semi xs-up:w=70 xs-up:mt=3</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>You could earn 87 SHARE points on this.I want to become a SHARE member.</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;AllsCartShareComponent&quot;)/div[@class=&quot;leo-share-component leo-share-component-cart-share xs-up:ls=0 xs-up.share-redeem-wrapper:mb=3 xs-up.share-info-row:d=flx xs-up.share-info-row:fs=p3 md-up.share-info-row:fs=p1 xs-up.share-info-row:flx-wrap=yes md-up.share-info-row:mb=3 xs-up.image-container:d=flx xs-up.image-container:w=100 md-up.image-container:w=25 md-up.image-container:pr=5 xs-up.share-logo:mr=auto xs-up.share-logo:mb=2 md-up.share-logo:mb=auto md-up.share-logo:mt=2 xs-up.share-logo:wmax=100 xs-up.info-container:d=flx xs-up.info-container:flx-dir=col xs-up.info-container:w=100 md-up.info-container:w=75 md-up.info-container:txt-align=center md-up.info-container>>.welcome-text:txt-align=left xs-up.user-info-container:d=flx xs-up.user-info-container:flx-dir=row xs-up.user-info-container:w=100 md-up.user-info-container:w=100 xs-up.user-info-container:fw=medium xs-up.user-info-container:mt=3 xs-up.user-info-container:fs=p3 xs-up.user-info-container>>.btn:mb=3 md-up.user-info-container:fs=p3 xs-up.user-info-container>>a:fc=body xs-up.desc:mt=2 xs-up.desc>u:fc=link xs-up.desc>u:cursor=pointer xs-up.desc>u:hover:fc=alpha xs-up.share-welcome-learn-more:mt=2 xs-up.share-welcome-learn-more:fc=link xs-up.welcome-description:fw=medium xs-up.share-redeem-row:d=flx xs-up.share-redeem-row:flx-dir=col xs-up.share-redeem-row:fs=p3 md-up.share-redeem-row:fs=p1 xs-up.share-id-wrapper:d=flx xs-up.share-id-name:w=50 md-up.share-id-name:w=30 xs-up.share-id-value:w=50 md-up.share-id-value:w=70 xs-up.share-id-value:fw=medium xs-up.available-points-wrapper:d=flx xs-up.share-points-name:w=50 md-up.share-points-name:w=30 xs-up.share-points-value:w=50 md-up.share-points-value:w=70 xs-up.share-points-value:fw=medium xs-up.points-to-earn-wrapper:d=flx xs-up.share-earn-name:w=50 md-up.share-earn-name:w=30 xs-up.share-earn-value:w=50 md-up.share-earn-value:w=70 xs-up.share-earn-value:fw=medium xs-up.redeem-form-wrapper:d=flx xs-up.redeem-form-wrapper:flx-wrap=yes xs-up.redeem-input-wrapper:wmin=100 md-up.redeem-input-wrapper:wmin=35 xs-up.redeem-input-wrapper:d=flx xs-up.redeem-input-wrapper:flx-dir=col xs-up.redeem-input-wrapper:fs=p3 xs-up.redeem-input-wrapper>>.col-form-label:fs=p3 md-up.redeem-input-wrapper>>.col-form-label:fs=p2 xs-up.redeem-input-wrapper:mb=3 xs-up.loyalty-btns-wrapper:d=flx xs-up.loyalty-btns-wrapper:mt=auto md-up.loyalty-btns-wrapper:mb=auto xs-up.loyalty-btns-wrapper:mb=3 xs-up.loyalty-btns-wrapper:w=100 md-up.loyalty-btns-wrapper:w=auto xs-up.loyalty-btns-wrapper:txt-wrap=no xs-up.loyalty-btns-wrapper:px=3 xs-up.loyalty-btns:hmin=(32px) xs-up.loyalty-btns:fw=medium xs-up.loyalty-btns:w=100 xs-up.loyalty-btns:mb=3 xs-up.redeem-loyalty-points:mr=2 md-up.redeem-loyalty-points:mr=0 xs-up.remove-loyalty-points:ml=2 md-up.remove-loyalty-points:ml=3 xs-up.points-used-placeholder:d=flx xs-up.points-used-placeholder:flx-dir=col xs-up.points-used-placeholder:mt=4 xs-up.points-used-placeholder:fs=p3 md-up.points-used-placeholder:fs=p2 xs-up.update-redeem-point>u:fc=link xs-up.update-redeem-point>u:cursor=pointer xs-up.update-redeem-point>u:hover:fc=alpha xs-up.share-redeem-wrapper:d=flx xs-up.share-redeem-wrapper:flx-dir=col xxl-up.share-redeem-wrapper:flx-dir=row xs-up.share-redeem-wrapper:flx-wrap=yes lg-up.share-info-row:flx-wrap=no xs-up.share-info-row:w=100 xs-up.share-logo:w=(11rem) xl-up.share-logo:w=(14rem) xs-up.share-logo:mt=0 xs-up.share-logo:mb=4 md-up.share-logo:my=2 sm-down.image-container:w=50 xs-up.image-container:w=auto md-up.image-container:w=(17rem) lg-up.image-container:wmin=(17rem) lg-up.info-container:w=70 lg-up.info-container:flx-justify-content=between sm-down.info-container:mb=3 xs-up.welcome-text:mt=0 xs-up.welcome-text:fs=p2 lg-up.user-info-container:mt=0 xs-up.user-info-container:flx-dir=col xs-up.user-info-container:txt-align=left xs-up.user-name:fs=p2 xs-up.user-email:fs=p2 xs-up.user-email:ml=0 xs-up.user-email:fw=regular xs-up.user-email:txt-align=left xs-up.share-redeem-row:fs=p2! xs-up.share-redeem-row:w=100 xs-up.share-id-name:w=(14rem) md-up.share-id-name:w=(17rem) lg-up.share-id-name:wmin=(17rem) xs-up.share-id-value:fw=regular xs-up.share-points-name:w=(14rem) md-up.share-points-name:w=(17rem) lg-up.share-points-name:wmin=(17rem) xs-up.share-points-value:fw=regular xs-up.share-earn-name:w=(14rem) md-up.share-earn-name:w=(17rem) lg-up.share-earn-name:wmin=(17rem) xs-up.share-earn-value:fw=regular xs-up.redeem-form-wrapper:w=100 md-up.redeem-input-wrapper:w=30 md-up.redeem-input-wrapper:wmin=30 xs-up.col-form-label:fw=medium xs-up.loyalty-btns:fw=regular xs-up.loyalty-btns:fs=p2 xs-up.loyalty-btns:fc=white xs-up.loyalty-btns:bc=transparent xs-up.loyalty-btns:bgc=gamma xs-up.loyalty-btns:br=(5px) xs-up.loyalty-btns:px=7 xs-up.form-control:bw=0 xs-up.form-control:bw-bottom=(1px) xs-up.loyalty-btns-wrapper:px=0 lg-up.loyalty-btns-wrapper:px=3 cart-share&quot;]/div[1]/div[1]/div[@id=&quot;undefined&quot;]/div[@class=&quot;leo-share-welcome-component leo-share-welcome-component-cart-share-welcome xs-up:ls=0 xs-up.share-redeem-wrapper:mb=3 xs-up.share-info-row:d=flx xs-up.share-info-row:fs=p3 md-up.share-info-row:fs=p1 xs-up.share-info-row:flx-wrap=yes md-up.share-info-row:mb=3 xs-up.image-container:d=flx xs-up.image-container:w=100 md-up.image-container:w=25 md-up.image-container:pr=5 xs-up.share-logo:mr=auto xs-up.share-logo:mb=2 md-up.share-logo:mb=auto md-up.share-logo:mt=2 xs-up.share-logo:wmax=100 xs-up.info-container:d=flx xs-up.info-container:flx-dir=col xs-up.info-container:w=100 md-up.info-container:w=75 md-up.info-container:txt-align=center md-up.info-container>>.welcome-text:txt-align=left xs-up.user-info-container:d=flx xs-up.user-info-container:flx-dir=row xs-up.user-info-container:w=100 md-up.user-info-container:w=100 xs-up.user-info-container:fw=medium xs-up.user-info-container:mt=3 xs-up.user-info-container:fs=p3 xs-up.user-info-container>>.btn:mb=3 md-up.user-info-container:fs=p3 xs-up.user-info-container>>a:fc=body xs-up.desc:mt=2 xs-up.desc>u:fc=link xs-up.desc>u:cursor=pointer xs-up.desc>u:hover:fc=alpha xs-up.share-welcome-learn-more:mt=2 xs-up.share-welcome-learn-more:fc=link xs-up.welcome-description:fw=medium xs-up.share-redeem-row:d=flx xs-up.share-redeem-row:flx-dir=col xs-up.share-redeem-row:fs=p3 md-up.share-redeem-row:fs=p1 xs-up.share-id-wrapper:d=flx xs-up.share-id-name:w=50 md-up.share-id-name:w=30 xs-up.share-id-value:w=50 md-up.share-id-value:w=70 xs-up.share-id-value:fw=medium xs-up.available-points-wrapper:d=flx xs-up.share-points-name:w=50 md-up.share-points-name:w=30 xs-up.share-points-value:w=50 md-up.share-points-value:w=70 xs-up.share-points-value:fw=medium xs-up.points-to-earn-wrapper:d=flx xs-up.share-earn-name:w=50 md-up.share-earn-name:w=30 xs-up.share-earn-value:w=50 md-up.share-earn-value:w=70 xs-up.share-earn-value:fw=medium xs-up.redeem-form-wrapper:d=flx xs-up.redeem-form-wrapper:flx-wrap=yes xs-up.redeem-input-wrapper:wmin=100 md-up.redeem-input-wrapper:wmin=35 xs-up.redeem-input-wrapper:d=flx xs-up.redeem-input-wrapper:flx-dir=col xs-up.redeem-input-wrapper:fs=p3 xs-up.redeem-input-wrapper>>.col-form-label:fs=p3 md-up.redeem-input-wrapper>>.col-form-label:fs=p2 xs-up.redeem-input-wrapper:mb=3 xs-up.loyalty-btns-wrapper:d=flx xs-up.loyalty-btns-wrapper:mt=auto md-up.loyalty-btns-wrapper:mb=auto xs-up.loyalty-btns-wrapper:mb=3 xs-up.loyalty-btns-wrapper:w=100 md-up.loyalty-btns-wrapper:w=auto xs-up.loyalty-btns-wrapper:txt-wrap=no xs-up.loyalty-btns-wrapper:px=3 xs-up.loyalty-btns:hmin=(32px) xs-up.loyalty-btns:fw=medium xs-up.loyalty-btns:w=100 xs-up.loyalty-btns:mb=3 xs-up.redeem-loyalty-points:mr=2 md-up.redeem-loyalty-points:mr=0 xs-up.remove-loyalty-points:ml=2 md-up.remove-loyalty-points:ml=3 xs-up.points-used-placeholder:d=flx xs-up.points-used-placeholder:flx-dir=col xs-up.points-used-placeholder:mt=4 xs-up.points-used-placeholder:fs=p3 md-up.points-used-placeholder:fs=p2 xs-up.update-redeem-point>u:fc=link xs-up.update-redeem-point>u:cursor=pointer xs-up.update-redeem-point>u:hover:fc=alpha xs-up:fc=dark xs-up:pt=3 xs-up.share-redeem-wrapper:mb=0 xs-up.share-info-row:w=100! xl-up.share-info-row:mb=0! xs-up.share-info-row:flx-dir=col md-up.share-info-row:flx-dir=row xs-up.image-container:d=block md-up.image-container:pr=4 lg-up.image-container:pr=6 xl-up.image-container:pr=9 xs-up.image-container:mb=3 xs-up.share-logo:mt=0! md-down.share-logo:ml=0 sm-down.share-logo:mb=3 lg-up.info-container:flx-dir=col xl-up.info-container:flx-dir=row xs-up.info-container:fs=(1.16rem)! xs-up.info-container:w=100! xl-up.info-container:w=65! xs-up.user-info-container:flx-dir=col xs-up.user-info-container:fw=medium! xs-up.user-info-container:mt=0! xs-up.user-info-container:txt-align=left xl-up.user-info-container:pl=8 md-up.user-info-container>>.desc:mt=0 xs-up.btn-join-today:fs=p3 xs-up.btn-join-today:fw=medium xs-up.btn-join-today:h=(36px) xs-up.btn-join-today:txt-case=upper xs-up.btn-join-today:bgc=gamma xs-up.btn-join-today:br=(5px) xs-up.btn-join-today:bc=transparent xs-up.btn-join-today:w=(fit-content) xs-up.btn-join-today:px=5 xs-up.btn-join-today:mb=4! xs-up.user-info-container>>u:fc=(#2778bc)! xs-up.share-welcome-learn-more:mt=4 xs-up.welcome-text:fw=medium xs-up.welcome-text:w=100 xs-up.welcome-text:mt=0 xs-up.welcome-text:pr=3 xs-up.welcome-text:mb=3 cart-share-welcome&quot;]/div[1]/div[@class=&quot;share-redeem-wrapper share-logged-out&quot;]/div[@class=&quot;share-info-row&quot;]/div[@class=&quot;info-container&quot;]/span[@class=&quot;welcome-text xs-up:fw=semi xs-up:w=70 xs-up:mt=3&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='undefined']/div/div/div/div/div[2]/span</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='AED 870.00'])[3]/following::span[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='AED 870.00'])[2]/following::span[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Join Today'])[1]/preceding::span[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Already have an account?'])[1]/preceding::span[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='You could earn 87 SHARE points on this.']/parent::*</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/span</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'You could earn 87 SHARE points on this.I want to become a SHARE member.' or . = 'You could earn 87 SHARE points on this.I want to become a SHARE member.')]</value>
   </webElementXpaths>
</WebElementEntity>
