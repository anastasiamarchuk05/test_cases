<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Header</name>
   <tag></tag>
   <elementGuidId>03caa749-9a0b-4b5c-9ca9-9fb7ebc48e9e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='ALLSAINTS'])[1]/following::div[13]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>container-fluid xs-up:bgc=body xs-up:bw-bottom=(1px) xs-up:bc=alpha xs-up>.row:mx=n1 md-up>.row:mx=auto md-up:px=5</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>SearchSaleSaleWomenAll SaleDressesTops &amp; ShirtsT-ShirtsCoats &amp; JacketsSkirts &amp; ShortsJeansKnitwearAccessoriesMenAll SaleShirtsT-ShirtsPolosJeansCoats &amp; JacketsSwimwearKnitwearSweatshirts &amp; HoodiesTrousersAccessoriesFree same day delivery for orders before 7PMWomenWomenClothingDressesTops &amp; ShirtsT-ShirtsSkirts &amp; ShortsSwimwearLeather JacketsJeansTrousers &amp; LeggingsSweatshirts &amp; HoodiesCoats &amp; JacketsKnitwearNational DayShoes And AccessoriesAll ShoesAll AccessoriesFragranceHandbagsCard Holders &amp; WalletsFace MasksShop DressesFree same day delivery for orders before 7PMMenMenClothingShirtsT-ShirtsPolosJeansLeather JacketsSwimwearCoats And JacketsKnitwearSweatshirts And HoodiesTrousersShortsNational DayShoes And AccessoriesAll ShoesAll AccessoriesWalletsFragranceBeltsFace MasksShop T-ShirtsFree same day delivery for orders before 7PMSearchSearch
            
              
            
            
          
            
              
            
            
          ALLSAINTSSign InWishlistSomething catch your eye?Sign in to see items you may have added using another computer or device.Sign inBag (0)You are in your cart!Sign in to see items you may have added using another computer or device.Sign in</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;xs-up:bgc=body xs-up.fa-times:icon-before=cross state-loading&quot;]/div[@class=&quot;body&quot;]/div[@class=&quot;xs-up:fc=alpha xs-up>>h1:fh=1 xs-up>>h2:fh=2 xs-up>>h3:fh=3 xs-up>>h4:fh=6 xs-up>>h5:fp=2 xs-up>>h6:fp=4 xs-up:ls=.1 sm-down:left=0 sm-down:pos=rel sm-down:transition=all xs-up[leo-icon]:lh=1 xs-up.icon:w=(1.125rem) xs-up.icon:h=(1.125rem) xs-up.icon:d=inblock xs-up.icon:stroke-width=(1.3867) xs-up&lt;&lt;.state-open-search:scrollable=none xs-up&lt;&lt;.state-open-search:hmax=100vh xs-up>>picture:wmin=(1px) xs-up>>picture:hmin=(1px) xs-up>>picture:d=block sm-down&lt;&lt;.state-mega-menu-open:left=(83%)&quot;]/cx-storefront[@class=&quot;stop-navigating&quot;]/header[1]/cx-page-layout[@class=&quot;header&quot;]/div[1]/div[@class=&quot;tpl-CartPageTemplate xs-up>.container-fluid>.row:h=(64px) xs-up:pos=rel&quot;]/div[@class=&quot;container-fluid xs-up:bgc=body xs-up:bw-bottom=(1px) xs-up:bc=alpha xs-up>.row:mx=n1 md-up>.row:mx=auto md-up:px=5&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='ALLSAINTS'])[1]/following::div[13]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div[2]/div</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'SearchSaleSaleWomenAll SaleDressesTops &amp; ShirtsT-ShirtsCoats &amp; JacketsSkirts &amp; ShortsJeansKnitwearAccessoriesMenAll SaleShirtsT-ShirtsPolosJeansCoats &amp; JacketsSwimwearKnitwearSweatshirts &amp; HoodiesTrousersAccessoriesFree same day delivery for orders before 7PMWomenWomenClothingDressesTops &amp; ShirtsT-ShirtsSkirts &amp; ShortsSwimwearLeather JacketsJeansTrousers &amp; LeggingsSweatshirts &amp; HoodiesCoats &amp; JacketsKnitwearNational DayShoes And AccessoriesAll ShoesAll AccessoriesFragranceHandbagsCard Holders &amp; WalletsFace MasksShop DressesFree same day delivery for orders before 7PMMenMenClothingShirtsT-ShirtsPolosJeansLeather JacketsSwimwearCoats And JacketsKnitwearSweatshirts And HoodiesTrousersShortsNational DayShoes And AccessoriesAll ShoesAll AccessoriesWalletsFragranceBeltsFace MasksShop T-ShirtsFree same day delivery for orders before 7PMSearchSearch
            
              
            
            
          
            
              
            
            
          ALLSAINTSSign InWishlistSomething catch your eye?Sign in to see items you may have added using another computer or device.Sign inBag (0)You are in your cart!Sign in to see items you may have added using another computer or device.Sign in' or . = 'SearchSaleSaleWomenAll SaleDressesTops &amp; ShirtsT-ShirtsCoats &amp; JacketsSkirts &amp; ShortsJeansKnitwearAccessoriesMenAll SaleShirtsT-ShirtsPolosJeansCoats &amp; JacketsSwimwearKnitwearSweatshirts &amp; HoodiesTrousersAccessoriesFree same day delivery for orders before 7PMWomenWomenClothingDressesTops &amp; ShirtsT-ShirtsSkirts &amp; ShortsSwimwearLeather JacketsJeansTrousers &amp; LeggingsSweatshirts &amp; HoodiesCoats &amp; JacketsKnitwearNational DayShoes And AccessoriesAll ShoesAll AccessoriesFragranceHandbagsCard Holders &amp; WalletsFace MasksShop DressesFree same day delivery for orders before 7PMMenMenClothingShirtsT-ShirtsPolosJeansLeather JacketsSwimwearCoats And JacketsKnitwearSweatshirts And HoodiesTrousersShortsNational DayShoes And AccessoriesAll ShoesAll AccessoriesWalletsFragranceBeltsFace MasksShop T-ShirtsFree same day delivery for orders before 7PMSearchSearch
            
              
            
            
          
            
              
            
            
          ALLSAINTSSign InWishlistSomething catch your eye?Sign in to see items you may have added using another computer or device.Sign inBag (0)You are in your cart!Sign in to see items you may have added using another computer or device.Sign in')]</value>
   </webElementXpaths>
</WebElementEntity>
