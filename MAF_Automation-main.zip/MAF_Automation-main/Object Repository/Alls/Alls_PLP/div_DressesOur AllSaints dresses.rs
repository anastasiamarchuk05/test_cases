<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_DressesOur AllSaints dresses</name>
   <tag></tag>
   <elementGuidId>54ba4c67-0863-4bfc-852c-3679ea1307c7</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.container-grid.container-fluid</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='AllsGrid-CategoryContentDynamic']/div/div/div/div/div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>container-grid container-fluid</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>DressesOur AllSaints dresses include bold asymmetric hemlines, floral patterns for the summer, animal prints, and knitted styles for cooler days. Choose from versatile 2-in-1 options or classic shift dresses.Read morelessAll Dresses2-In-1 DressesMaxi DressesMidi DressesOccasion DressesPrinted Dresses</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;AllsGrid-CategoryContentDynamic&quot;)/div[@class=&quot;leo-advanced-grid-component leo-advanced-grid-component-grid-nav-alpha xs-up:grid:pos=rel xs-up:grid-bg:pos-overlay=abs xs-up:grid-bg-img:w=100 xs-up:grid-bg-img:h=100 xs-up:grid-bg-img:pos=abs xs-up:grid-bg-img:ofit=cover xs-up:grid-bg-img:opos=center xs-up:grid-col-item:not([class*=&quot;offset&quot;]):mx=auto xs-up:grid-col-components:h=100 xs-up:grid-col-components:h=auto xs-up:pos=rel xs-up:grid:mb=0 xs-up:grid-container:pb=3 xs-up:grid-container:px=(2.09rem) lg-up:grid-container:px=(3.4rem) xs-up:grid-title:fs=(2.34rem) lg-up:grid-title:fs=h3 xs-up:grid-title:ff=beta xs-up:grid-title:mb=3 xs-up:grid-title:lh=(1.11) xs-up:grid-title:ls=(0.13rem) xs-up&lt;:after:content=() xs-up&lt;:after:pos-align=bottom-right xs-up&lt;:after:right=5 xs-up&lt;:after:h=(5rem) xs-up&lt;:after:w=(3.4rem) xs-up&lt;:after:linear-gradient=(90deg,rgba(255,255,255,0.01),rgba(255,255,255,1)) lg-up:mx=7 lg-up:bw-bottom=(1px) grid-nav-alpha&quot;]/div[1]/div[@class=&quot;sticky&quot;]/div[@class=&quot;wrapper-grid&quot;]/div[@class=&quot;container-grid container-fluid&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='AllsGrid-CategoryContentDynamic']/div/div/div/div/div</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Dresses'])[2]/following::div[14]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Clothing'])[4]/following::div[14]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//cx-storefront/cx-page-layout/div/div/div/div/div/cx-page-slot/div/div/div/div/div/div/div</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'DressesOur AllSaints dresses include bold asymmetric hemlines, floral patterns for the summer, animal prints, and knitted styles for cooler days. Choose from versatile 2-in-1 options or classic shift dresses.Read morelessAll Dresses2-In-1 DressesMaxi DressesMidi DressesOccasion DressesPrinted Dresses' or . = 'DressesOur AllSaints dresses include bold asymmetric hemlines, floral patterns for the summer, animal prints, and knitted styles for cooler days. Choose from versatile 2-in-1 options or classic shift dresses.Read morelessAll Dresses2-In-1 DressesMaxi DressesMidi DressesOccasion DressesPrinted Dresses')]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Clothing'])[3]/following::div[14]</value>
   </webElementXpaths>
</WebElementEntity>
