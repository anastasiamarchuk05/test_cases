<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>ul_ClothingDressesTops ShirtsT-ShirtsSkirt</name>
   <tag></tag>
   <elementGuidId>af4f172a-da7e-41c4-8bd7-6d4bc75743fd</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='AllsCategoryNavComponent']/div/div/ul/li[2]/div[2]/ul</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>li.nav-item.nav-item-primary.has-sub.state-hover-open > div.header-navbar-submenu.header-navbar-submenu-alpha.container > ul.navbar-submenu-primary</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>ul</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>navbar-submenu-primary</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>ClothingDressesTops &amp; ShirtsT-ShirtsSkirts &amp; ShortsSwimwearLeather JacketsJeansTrousers &amp; LeggingsSweatshirts &amp; HoodiesCoats &amp; JacketsKnitwearNational Day</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;AllsCategoryNavComponent&quot;)/div[@class=&quot;leo-category-navigation-component leo-category-navigation-component-mega-menu-alpha sm-down:pos=abs sm-down:left=(2rem) sm-down:right=(2rem) sm-down:top=(61px) sm-down:bottom=(80px) sm-down:scrollable=y xs-up.menu-overlay:bgc=white-80 xs-up.menu-overlay:w=100vw xs-up.menu-overlay:pos-overlay=abs md-up.menu-overlay:top=(20rem) xs-up.menu-overlay:z=1 xs-up.menu-overlay:d=none xs-up&lt;&lt;.state-mega-menu-open>>.menu-overlay:d=block sm-down&lt;&lt;.state-mega-menu-open>>.menu-overlay:left=(100.5%) sm-down.sub-active>>.leo-image-link-component:d=none sm-down.sub-active>>.leo-link-component-link-default:d=none xs-up.header-navbar:list-style=none xs-up.header-navbar:flx-row-align=top-between md-up.header-navbar:flx-row-align=center-left xs-up.header-navbar>>li:z=3 xs-up.header-navbar>>li.link:pos=static xs-up.header-navbar>>li.link:d=block sm-down.header-navbar:pt=6 sm-down.header-navbar:scrollable=y sm-down.header-navbar:flx-wrap=yes sm-down.header-navbar:pos=rel sm-down.header-navbar:z=1 md-up.header-tabs:w=auto xs-up.go-back:flx-row-align=center-left xs-up.go-back:pos=rel xs-up.go-back:after:content=() xs-up.go-back:after:pos-overlay=abs xs-up.go-back:before:content=() xs-up.go-back:before:bw=(0.5px) xs-up.go-back:before:bw-top=0 xs-up.go-back:before:bw-right=0 xs-up.go-back:before:p=(4px) xs-up.go-back:before:ml=(2px) xs-up.go-back:before:mr=(8px) xs-up.go-back:before:d=inblock xs-up.go-back:before:rotate=45 xs-up.go-back>>img:d=none xs-up.go-back>>.caption:my=0! md-up.go-back:d=none xs-up.nav-item-primary>>.link>>.is-missing:d=none md-up.nav-item-primary.state-hover-open>.header-navbar-submenu:d=flx md-up.nav-item-primary.state-click-open>.header-navbar-submenu:d=flx sm-down.nav-item-primary:w=45 sm-down.nav-item-primary.has-sub>[leo-nav]>>.link:pointer-events=disabled sm-down.state-menu-open>.nav-item-primary.state-click-open:w=100 sm-down.nav-item-primary.state-click-open>.header-navbar-submenu:d=block sm-down.state-menu-open>.nav-item-primary.state-click-open>[leo-nav]:d=none sm-down.state-menu-open>.nav-item-primary:not(.state-click-open):d=none sm-down.header-navbar-submenu:hmax=(80%) sm-down.header-navbar-submenu:scrollable=y sm-down.header-navbar-submenu:px=0 sm-down.header-navbar-submenu:pb=3 sm-down.header-navbar-submenu>>[leo-media]:d=none xs-up.header-navbar-submenu:d=none md-up.header-navbar-submenu:pos=abs md-up.header-navbar-submenu:leri=0 md-up.header-navbar-submenu:wmax=100 md-up.header-navbar-submenu:bw-bottom=(1px) md-up.header-navbar-submenu:bc-bottom=alpha md-up.header-navbar-submenu:bw-top=(18px) md-up.header-navbar-submenu:bc-top=transparent md-up.header-navbar-submenu:px=4 md-up.header-navbar-submenu:pb=(5rem) md-up.header-navbar-submenu:bgc=body md-up.header-navbar-submenu:z=1 md-up.header-navbar-submenu:before:content=() md-up.header-navbar-submenu:before:pos=abs md-up.header-navbar-submenu:before:leri=6 md-up.header-navbar-submenu:before:bw-top=(1px) xs-up.navbar-submenu-primary:list-style=none md-up.navbar-submenu-primary:p=3 md-up.navbar-submenu-primary:wmin=20 md-up.navbar-submenu-primary:txt-align=left md-up.navbar-submenu-primary:last-child:w=100! md-up.navbar-submenu-primary:last-child:bottom=0 md-up.navbar-submenu-primary:last-child:mb=2 md-up.navbar-submenu-primary:last-child:pt=0 md-up.navbar-submenu-primary:last-child:pos=abs xs-up.navbar-submenu-secondary:list-style=none md-up.submenu-primary-item:mt=5 mega-menu-alpha&quot;]/div[1]/ul[@class=&quot;header-navbar&quot;]/li[@class=&quot;nav-item nav-item-primary has-sub state-hover-open&quot;]/div[@class=&quot;header-navbar-submenu header-navbar-submenu-alpha container&quot;]/ul[@class=&quot;navbar-submenu-primary&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='AllsCategoryNavComponent']/div/div/ul/li[2]/div[2]/ul</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Women'])[3]/following::ul[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Women'])[2]/following::ul[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[2]/div[2]/ul</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//ul[(text() = 'ClothingDressesTops &amp; ShirtsT-ShirtsSkirts &amp; ShortsSwimwearLeather JacketsJeansTrousers &amp; LeggingsSweatshirts &amp; HoodiesCoats &amp; JacketsKnitwearNational Day' or . = 'ClothingDressesTops &amp; ShirtsT-ShirtsSkirts &amp; ShortsSwimwearLeather JacketsJeansTrousers &amp; LeggingsSweatshirts &amp; HoodiesCoats &amp; JacketsKnitwearNational Day')]</value>
   </webElementXpaths>
</WebElementEntity>
