<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_All Dresses2-In-1 DressesMaxi Dresses</name>
   <tag></tag>
   <elementGuidId>93dd482a-0e88-4a3f-972c-a72605cc7cce</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='AllsGrid-CategoryContentDynamic']/div/div/div/div/div/div[2]/div[4]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.container-grid.container-fluid > div.row > div.col-12.col-last.col-item</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>col-12 col-last col-item</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>All Dresses2-In-1 DressesMaxi DressesMidi DressesOccasion DressesPrinted Dresses</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;AllsGrid-CategoryContentDynamic&quot;)/div[@class=&quot;leo-advanced-grid-component leo-advanced-grid-component-grid-nav-alpha xs-up:grid:pos=rel xs-up:grid-bg:pos-overlay=abs xs-up:grid-bg-img:w=100 xs-up:grid-bg-img:h=100 xs-up:grid-bg-img:pos=abs xs-up:grid-bg-img:ofit=cover xs-up:grid-bg-img:opos=center xs-up:grid-col-item:not([class*=&quot;offset&quot;]):mx=auto xs-up:grid-col-components:h=100 xs-up:grid-col-components:h=auto xs-up:pos=rel xs-up:grid:mb=0 xs-up:grid-container:pb=3 xs-up:grid-container:px=(2.09rem) lg-up:grid-container:px=(3.4rem) xs-up:grid-title:fs=(2.34rem) lg-up:grid-title:fs=h3 xs-up:grid-title:ff=beta xs-up:grid-title:mb=3 xs-up:grid-title:lh=(1.11) xs-up:grid-title:ls=(0.13rem) xs-up&lt;:after:content=() xs-up&lt;:after:pos-align=bottom-right xs-up&lt;:after:right=5 xs-up&lt;:after:h=(5rem) xs-up&lt;:after:w=(3.4rem) xs-up&lt;:after:linear-gradient=(90deg,rgba(255,255,255,0.01),rgba(255,255,255,1)) lg-up:mx=7 lg-up:bw-bottom=(1px) grid-nav-alpha&quot;]/div[1]/div[@class=&quot;sticky&quot;]/div[@class=&quot;wrapper-grid&quot;]/div[@class=&quot;container-grid container-fluid&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-12 col-last col-item&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='AllsGrid-CategoryContentDynamic']/div/div/div/div/div/div[2]/div[4]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='less'])[1]/following::div[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='more'])[1]/following::div[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div[4]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'All Dresses2-In-1 DressesMaxi DressesMidi DressesOccasion DressesPrinted Dresses' or . = 'All Dresses2-In-1 DressesMaxi DressesMidi DressesOccasion DressesPrinted Dresses')]</value>
   </webElementXpaths>
</WebElementEntity>
