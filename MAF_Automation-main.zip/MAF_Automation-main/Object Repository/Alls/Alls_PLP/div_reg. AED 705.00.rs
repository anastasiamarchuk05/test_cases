<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_reg. AED 705.00</name>
   <tag></tag>
   <elementGuidId>da58b230-1877-4dbe-8e54-5fe5348b5509</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(//div[@id='undefined']/div/div/div[2])[44]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>crossed-price</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>reg. AED 705.00</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;ProductListComponent&quot;)/div[@class=&quot;leo-product-list-component leo-product-list-component-product-grid-alpha-three-columns xs-up:product-grid:pos=rel xs-up:product-grid-col-item-inner:h=100 xs-up:ff=beta xs-up:hmin=(400px) md-up:hmin=(500px) lg-up:hmin=(700px) xs-up:product-grid-container:px=4 lg-up:product-grid-container:px=(5.5rem) lg-up:product-grid-container:wmax=100 xs-up:product-grid-row-group:mb=5 xs-up:product-grid-col-item-inner:d=flx xs-up:product-grid-col-item-inner:flx-dir=col xs-up:product-grid-col-item-inner:pos=rel xs-up:product-grid-col-item-inner:pr=0 md-up:product-grid-col-item-inner:pr=6 xs-up:product-grid-col-item-inner:pl=0 md-up:product-grid-col-item-inner:pl=0 lg-up:product-grid-col-item-inner:pl=0 xs-up.row-image+.row:mt=5 xs-up.row-image>.col-item>.col-item-inner:px=0! md-up.row-add-to-wishlist>>.col-item:hover>>.tile-add-to-wishlist:d=flx lg-up.tile-add-to-wishlist:d=none xs-up.tile-add-to-wishlist:pos-align=top-right xs-up.tile-add-to-wishlist>>.btn-wishlist:before:square=(1.333rem) xs-up.tile-add-to-wishlist:bottom=auto md-down>>.col-6>>.tile-add-to-wishlist:bottom=2 md-down>>.col-6>>.tile-add-to-wishlist:top=auto lg-up.tile-add-to-wishlist:top=n1 xs-up.tile-variant-selector-advanced>>.features-group:mb=3 xs-up.tile-variant-selected-item>>.variant-list:mb=3 xs-up.tile-name:pr=7 md-down>>.col-6>>.tile-name:pr=0 xs-up.tile-summary>>.summary:mb=3 xs-up.tile-add-to-cart:mt=auto xs-up.tile-image:d=flx xs-up.tile-image:h=100 xs-up.tile-image>div:w=100 xs-up:product-grid-alpha-two-columns lg-up:product-grid-alpha-three-columns md-down.tile-variant-selector-simple>>.size:d=none&quot;]/div[1]/div[@class=&quot;container container-grid&quot;]/div[@class=&quot;row-group&quot;]/div[@class=&quot;row row-add-to-wishlist row-badges row-name row-price row-variant-selector-simple row-add-to-cart row-stock-badge-cta&quot;]/div[@class=&quot;col-item col-4&quot;]/div[@class=&quot;col-item-inner&quot;]/div[@class=&quot;tile tile-price&quot;]/div[@id=&quot;undefined&quot;]/div[@class=&quot;leo-product-price-component leo-product-price-component-product-price-alpha xs-up&lt;&lt;.list-view>>.price:fs=(1.333rem) xs-up.price:fs=p2 md-up.price:fs=p1 xs-up.price:fw=normal xs-up.price.state-cross:fc=danger xs-up&lt;&lt;.container-grid>>.price:mb=1 xs-up&lt;&lt;.list-view>>.price:mb=0 xs-up.crossed-price:fc=black-70 xs-up&lt;&lt;.selected-combination-disabled:d=none xs-up.price:fw=semi product-price-alpha&quot;]/div[1]/div[@class=&quot;crossed-price&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>(//div[@id='undefined']/div/div/div[2])[44]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sale AED 490.00'])[1]/following::div[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='HATTI TEE DRESS'])[1]/following::div[6]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Selected option is no longer available.'])[42]/preceding::div[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='reg. AED 705.00']/parent::*</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/div/div[4]/div/div/div/div[2]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'reg. AED 705.00' or . = 'reg. AED 705.00')]</value>
   </webElementXpaths>
</WebElementEntity>
