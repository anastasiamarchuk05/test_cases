<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Bag (0)</name>
   <tag></tag>
   <elementGuidId>2b70028d-791d-4dda-8c3d-d64db21fec34</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='AllsUserMenuMiniCart']/div/div/div/a/span</value>
      </entry>
      <entry>
         <key>CSS</key>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>user-menu-text</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Bag (0)</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;AllsUserMenuMiniCart&quot;)/div[@class=&quot;leo-mini-cart-component leo-mini-cart-component-user-menu-alpha-cart xs-up:pos=rel xs-up:p=2 xs-up.user-mennu-link:d=flx xs-up.user-menu-link:pos=rel xs-up.user-menu-link:txt-case=upper xs-up.user-menu-link:fs=p4 xs-up.user-menu-link:ls=.1 xs-up.user-menu-link:fw=medium xs-up.user-menu-link:icon-after=underline-left-to-right xs-up.user-menu-link:after:bw-bottom=(1px) xs-up.user-menu-link:after:d=block xs-up.user-menu-link:after:mt=(2px) xs-up.user-menu-link:after:bottom=n2 xs-up.user-menu-link:hover:txt-underline=no xs-up.user-menu-link:hover:icon-after=underline-left-to-right-scale xs-up.user-menu-link:txt-underline=no xs-up.user-menu-link:flx-row-align=center-center xs-up.user-menu-text:flx-row-align=center-center sm-down.user-menu-text:d=none md-up.user-menu-link>[leo-icon]:d=none xs-up.user-menu-link>[leo-icon]:pos=rel xs-up.user-menu-link>[leo-icon]:after:content=() xs-up.user-menu-link>[leo-icon]:after:bc=alpha xs-up.user-menu-link>[leo-icon]:after:bw-bottom=(0.25rem) xs-up.user-menu-link>[leo-icon]:after:pt=2 xs-up.user-menu-link>[leo-icon]:after:bottom=n2 xs-up.user-menu-link>[leo-icon]:after:d=none xs-up.user-menu-link>[leo-icon]:after:pos=abs xs-up.user-menu-link>[leo-icon]:after:right=0 xs-up.user-menu-link>[leo-icon]:after:w=100 xs-up.user-menu-dropdown:bw-left=(.5px) xs-up.user-menu-dropdown:bc=alpha-20 xs-up.user-menu-dropdown:bgc=body xs-up.user-menu-dropdown:p=4 xs-up.user-menu-dropdown:flx-dir=col md-up&lt;:hover>>.user-menu-link>[leo-icon]:after:d=block xs-up.state-modal-open>>.user-menu-dropdown:d=flx! md-up&lt;&lt;.modal-dialog>>.state-modal-open>>.modal-backdrop:d=none md-up.state-modal-open>>.modal-backdrop:d=block md-up.state-modal-open>>.modal-backdrop:bgc=white md-up.state-modal-open>>.modal-backdrop:opacity=80 xs-up.content:not(:last-child):mb=4 xs-up.content>>a:txt-underline=yes xs-up.btn-cta:btn=alpha xs-up.btn-cta:w=100 xs-up.btn-cta:mb=3 xs-up.btn-cta:h=(3.34rem) xs-up.more-items-text:txt-align=center xs-up.user-menu-dropdown:d=none xs-up.user-menu-dropdown:fs=p3 xs-up.user-menu-dropdown:pos=fix xs-up.user-menu-dropdown:top=0 xs-up.user-menu-dropdown:right=0 md-down.user-menu-dropdown:left=0 xs-up.user-menu-dropdown:w=100 lg-up.user-menu-dropdown:w=(33.4rem) xs-up.user-menu-dropdown:h=100 xs-up.user-menu-dropdown:px=6 xs-up.user-menu-dropdown:pt=0 xs-up.user-menu-dropdown:pb=3 xs-up.user-menu-dropdown:z=9999 xs-up.headline:fs=(28px) xs-up.headline:ff=beta xs-up.headline:bw-bottom=(1px) xs-up.headline:lh=(60px) xs-up.headline:ls=.08 xs-up.content:d=none xs-up.close:p=0 xs-up.close:m=0 xs-up.close:pos=abs xs-up.close:top=(1.75rem) xs-up.close:right=6 xs-up.close:opacity=100! xs-up.close>span:d=none xs-up.close:icon-before=remove xs-up.close:before:square=(23px) xs-up.products:flx=fill xs-up.products:scrollable=y xs-up.product:py=7 xs-up.product:bc-bottom=black xs-up.product:not(:last-child):bw-bottom=(1px) xs-up.cart-item-read-only-product:hover:txt-underline=no xs-up.cart-item-read-only-product:flx-row-align=top-between xs-up.cart-item-read-only-product:pointer-events=disabled xs-up.cart-item-read-only-product-info:pr=3 xs-up.cart-item-read-only-product-name:fs=p1 xs-up.cart-item-read-only-product-name:ff=beta xs-up.cart-item-read-only-product-name:ls=.06 xs-up.cart-item-read-only-product-image>>img:wmax=(10rem) xs-up.cart-item-read-only-product-image>>img:wmin=(10rem) xs-up.cart-item-read-only-product-image:flx-order=2 xs-up.cart-item-read-only-product-info:flx-order=1 xs-up.cart-item-read-only-product-info:d=flx xs-up.cart-item-read-only-product-info:flx-dir=col xs-up.cart-item-read-only-product-info:flx-align-items=start xs-up.price:fs=p1 xs-up.price:ff=beta xs-up.price:ls=.06 xs-up.price:mb=3 xs-up.size-variant:txt-case=upper xs-up.size-variant:fs=p4 xs-up.size-variant:ls=.08 xs-up.size-variant:mb=1 xs-up.quantity:txt-case=upper xs-up.quantity:fs=p4 xs-up.quantity:ls=.08 xs-up.quantity:mb=3 xs-up.btn-remove:bgc=transparent xs-up.btn-remove:bw=0 xs-up.btn-remove:px=0 xs-up.btn-remove:fs=p4 xs-up.btn-remove:txt-case=upper xs-up.btn-remove:w=(fit-content) xs-up.btn-remove:pos=rel xs-up.btn-remove:pointer-events=active! xs-up.btn-remove:icon-after=underline-left-to-right-scale xs-up.btn-remove:after:bw-bottom=(1px) xs-up.btn-remove:after:d=block xs-up.btn-remove:after:bottom=0 xs-up.btn-remove:hover:txt-underline=no xs-up.btn-remove:hover:icon-after=underline-left-to-right xs-up.cart-total-price:bw-top=(1px) xs-up.cart-total-price:flx-row-align=center-between xs-up.cart-total-price:fs=center-between xs-up.cart-total-price:ff=beta xs-up.cart-total-price:fs=h6 xs-up.cart-total-price:py=4 xs-up.btn-cta:fs=p4 xs-up.empty-cart:mt=4 xs-up.empty-cart:mb=auto xs-up.empty-cart:fs=h6 xs-up.empty-cart:ff=beta sm-down.user-menu-text:bgc=mid sm-down.user-menu-text:br=full sm-down.user-menu-text:b=(1px) sm-down.user-menu-text:bc=body sm-down.user-menu-text:fc=body sm-down.user-menu-text:fw=normal sm-down.user-menu-text:fs=p5 sm-down.user-menu-text:txt-align=center sm-down.user-menu-text:pos=abs sm-down.user-menu-text:w=(1rem) sm-down.user-menu-text:h=(1rem) sm-down.user-menu-text:top=(-0.5rem) sm-down.user-menu-text:right=(-0.25rem) sm-down.state-empty>>.user-menu-text:d=none xxl-up.user-menu-text:fs=(1.17rem) sm-down.icon:w=(1.5rem) sm-down.icon:h=(1.5rem) lg-up.icon:w=(1.25rem) lg-up.icon:h=(1.25rem) xs-up.state-not-empty>>.icon:d=none xs-up.state-not-empty>>[leo-icon]:icon-before=shopping-bag xs-up.state-page>>.btn-cta:d=none xs-up.state-empty>>.btn-cta:d=none xs-up.state-page>>.cart-total-price:d=none xs-up.state-page>>.empty-cart:d=none user-menu-alpha-cart&quot;]/div[1]/div[@class=&quot;user-menu-wrapper state-mini state-anonymous state-empty&quot;]/a[@class=&quot;user-menu-link&quot;]/span[@class=&quot;user-menu-text&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='AllsUserMenuMiniCart']/div/div/div/a/span</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sign in'])[2]/following::span[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sign in'])[1]/following::span[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Are you missing items in your cart?'])[1]/preceding::span[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Bag (0)']/parent::*</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[4]/div/div/div/div/a/span</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Bag (0)' or . = 'Bag (0)')]</value>
   </webElementXpaths>
</WebElementEntity>
