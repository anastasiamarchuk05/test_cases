<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_Accept Cookies</name>
   <tag></tag>
   <elementGuidId>5452f68d-3268-4e14-8cd2-89b72ee0c810</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>button.btn-cookie-warning-accept</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='AllsAnonymousConsentManagementBannerComponent']/div/div/div/div/div/div/div/button[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>button</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>btn-cookie-warning-accept</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> Accept Cookies </value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;AllsAnonymousConsentManagementBannerComponent&quot;)/div[@class=&quot;leo-advanced-responsive-banner-component leo-advanced-responsive-banner-component-cookie-warning-alpha xs-up.cookie-warning-container:fs=p3 xs-up.cookie-warning-container:fc=body xs-up.cookie-warning-container:p=3 md-up.cookie-warning-container:p=2 xs-up.cookie-warning-container:pos=rel md-up.cookie-warning-banner:px=2 xs-up.cookie-warning-banner:flx-row-align=center-center sm-down.cookie-warning-banner:flx-wrap=yes sm-down.cookie-warning-banner>[leo-banner]:w=100 sm-down.cookie-warning-banner>>.content:pb=3 xs-up.cookie-warning-banner>>.content>>p:mb=1 sm-down.content-truncate:scrollable=y sm-down.content-truncate:hmax=(11vh) xs-up.btn-cookie-warning-details:btn=transparent xs-up.btn-cookie-warning-details:fc=white xs-up.btn-cookie-warning-details:fs=p4 xs-up.btn-cookie-warning-details:p=4 sm-down.btn-cookie-warning-details:ml=3 xs-up.btn-cookie-warning-details:txt-underline=yes xs-up.btn-cookie-warning-details:hover:txt-underline=no xs-up.btn-cookie-warning-accept:btn=transparent xs-up.btn-cookie-warning-accept:fc=white xs-up.btn-cookie-warning-accept:fs=p4 xs-up.btn-cookie-warning-accept:p=4 sm-down.btn-cookie-warning-accept:ml=3 xs-up.btn-cookie-warning-accept:bw=(1px) xs-up.btn-cookie-warning-accept:bc=white xs-up.btn-cookie-warning-accept:hover:fc=black xs-up.btn-cookie-warning-accept:hover:bgc=muted xs-up>>a:fc=white xs-up>>a:txt-underline=yes xs-up>>a:hover:txt-underline=no cookie-warning-alpha&quot;]/div[1]/div[@class=&quot;cookie-warning-container&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-12&quot;]/div[@class=&quot;cookie-warning-banner&quot;]/button[@class=&quot;btn-cookie-warning-accept&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='AllsAnonymousConsentManagementBannerComponent']/div/div/div/div/div/div/div/button[2]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Manage Cookies'])[1]/following::button[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='ALLSAINTS'])[1]/following::button[4]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Search'])[1]/preceding::button[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sale'])[1]/preceding::button[3]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Accept Cookies']/parent::*</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/button[2]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//button[(text() = ' Accept Cookies ' or . = ' Accept Cookies ')]</value>
   </webElementXpaths>
</WebElementEntity>
