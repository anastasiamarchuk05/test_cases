<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Hello, Tanya</name>
   <tag></tag>
   <elementGuidId>41d6e68b-1d86-4c7f-9374-34468a97c78d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='AllsUserMenuMiniAccount']/div/div/div/a/span</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>span.user-menu-text</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>user-menu-text</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Hello, Tanya</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;AllsUserMenuMiniAccount&quot;)/div[@class=&quot;leo-account-drop-down-component leo-account-drop-down-component-user-menu-alpha-account xs-up:pos=rel xs-up:p=2 xs-up.user-mennu-link:d=flx xs-up.user-menu-link:pos=rel xs-up.user-menu-link:txt-case=upper xs-up.user-menu-link:fs=p4 xs-up.user-menu-link:ls=.1 xs-up.user-menu-link:fw=medium xs-up.user-menu-link:icon-after=underline-left-to-right xs-up.user-menu-link:after:bw-bottom=(1px) xs-up.user-menu-link:after:d=block xs-up.user-menu-link:after:mt=(2px) xs-up.user-menu-link:after:bottom=n2 xs-up.user-menu-link:hover:txt-underline=no xs-up.user-menu-link:hover:icon-after=underline-left-to-right-scale xs-up.user-menu-link:txt-underline=no xs-up.user-menu-link:flx-row-align=center-center xs-up.user-menu-text:flx-row-align=center-center sm-down.user-menu-text:d=none md-up.user-menu-link>[leo-icon]:d=none xs-up.user-menu-link>[leo-icon]:pos=rel xs-up.user-menu-link>[leo-icon]:after:content=() xs-up.user-menu-link>[leo-icon]:after:bc=alpha xs-up.user-menu-link>[leo-icon]:after:bw-bottom=(0.25rem) xs-up.user-menu-link>[leo-icon]:after:pt=2 xs-up.user-menu-link>[leo-icon]:after:bottom=n2 xs-up.user-menu-link>[leo-icon]:after:d=none xs-up.user-menu-link>[leo-icon]:after:pos=abs xs-up.user-menu-link>[leo-icon]:after:right=0 xs-up.user-menu-link>[leo-icon]:after:w=100 xs-up.user-menu-dropdown:bw-left=(.5px) xs-up.user-menu-dropdown:bc=alpha-20 xs-up.user-menu-dropdown:bgc=body xs-up.user-menu-dropdown:p=4 xs-up.user-menu-dropdown:flx-dir=col md-up&lt;:hover>>.user-menu-link>[leo-icon]:after:d=block xs-up.state-modal-open>>.user-menu-dropdown:d=flx! md-up&lt;&lt;.modal-dialog>>.state-modal-open>>.modal-backdrop:d=none md-up.state-modal-open>>.modal-backdrop:d=block md-up.state-modal-open>>.modal-backdrop:bgc=white md-up.state-modal-open>>.modal-backdrop:opacity=80 xs-up.content:not(:last-child):mb=4 xs-up.content>>a:txt-underline=yes xs-up.btn-cta:btn=alpha xs-up.btn-cta:w=100 xs-up.btn-cta:mb=3 xs-up.btn-cta:h=(3.34rem) xs-up.more-items-text:txt-align=center sm-down.icon:w=(1.275rem) sm-down.icon:h=(1.275rem) xs-up:none md-up:user-menu-alpha-account&quot;]/div[1]/div[@class=&quot;user-menu-wrapper state-user&quot;]/a[@class=&quot;user-menu-link&quot;]/span[@class=&quot;user-menu-text&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='AllsUserMenuMiniAccount']/div/div/div/a/span</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='ALLSAINTS'])[2]/following::span[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Search'])[3]/following::span[4]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Wishlist'])[1]/preceding::span[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Something catch your eye?'])[1]/preceding::span[2]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Hello, Tanya']/parent::*</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div/div/div/a/span</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Hello, Tanya' or . = 'Hello, Tanya')]</value>
   </webElementXpaths>
</WebElementEntity>
