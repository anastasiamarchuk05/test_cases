<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>body_ALLSAINTSSearchSale</name>
   <tag></tag>
   <elementGuidId>d386c72e-0352-4b36-ac0e-d7afa8c5a9a6</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//body</value>
      </entry>
      <entry>
         <key>CSS</key>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>body</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>xs-up:bgc=body xs-up.fa-times:icon-before=cross state-loading modal-open</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>dir</name>
      <type>Main</type>
      <value>ltr</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
    
      ALLSAINTS
      
    
        
    
SearchSaleWomenWomenClothingDressesTops &amp; ShirtsT-ShirtsSkirts &amp; ShortsSwimwearLeather JacketsJeansTrousers &amp; LeggingsSweatshirts &amp; HoodiesCoats &amp; JacketsKnitwearNational DayShoes And AccessoriesAll ShoesAll AccessoriesFragranceHandbagsCard Holders &amp; WalletsFace MasksShop DressesFree same day delivery for orders before 7PMMenSearchSearch
            
              
            
            
          
            
              
            
            
          ALLSAINTSSign InWishlistSomething catch your eye?Sign in to see items you may have added using another computer or device.Sign inBag (1)Lee Lace Dress AED 650.00 Size: SQUANTITY: 1 Remove Sign in to see items you may have added using another computer or device.CHECKOUTENJOY 20% OFF YOUR FIRST PURCHASE - USE CODE HELLO20SHOP NOWHomeHomeWomenWomenClothingClothingLee Lace DressPreviousBack to DressesNextTap To ZoomTap To ZoomTap To ZoomTap To ZoomTap To ZoomTap To ZoomPreviousBack to DressesNextLee Lace DressSKU: UPV0830016AED 650.00
  
    
      or 4 interest-free payments of 162.50 AED.
      Learn more
      
    

    
    
  

            new TabbyPromo({
                selector: '#TabbyPromo',
                currency: 'AED',
                price: '650',
                installmentsCount: 4,
                lang: 'en',
            }); Selected option is no longer available. Color: BlackBlackSize: S X XS S S M M L LAdd to BagAdd to favoritesEarn 65 points NotesDress it up. The Lee Lace Dress. It's an off-duty essential. With a sweatshirt body. And lace-trimmed hem.  Instant layerPulloverShort lengthLong sleeveCrew neckLace trim at the hemModel is 5'9&quot;/177cm and wears a size Medium DetailsSHARERECENTLY VIEWEDLee Lace DressUPV0830016AED 650.00Add to BagNew to AllSaints? Sign up for 20% off full-price styles in your first order. Email Address  SEND INFORMATIONContact UsReturns &amp; ExchangeShipping and FAQsSize GuideTrack OrderTerms &amp; ConditionsPrivacy PolicySite MapFOLLOW USInstagramCOPYRIGHT © 2021 ALLSAINTS ALL RIGHTS RESERVED*ORDERS BEFORE 7PM
    
      Please enable JavaScript to continue using this application.
    
  


(function(){var l=function(e,g,f,h){this.get=function(a){a+=&quot;\x3d&quot;;for(var b=document.cookie.split(&quot;;&quot;),c=0,k=b.length;c&lt;k;c++){for(var d=b[c];&quot; &quot;==d.charAt(0);)d=d.substring(1,d.length);if(0==d.indexOf(a))return d.substring(a.length,d.length)}return null};this.set=function(a,b){var c=new Date;c.setTime(c.getTime()+6048E5);c=&quot;; expires\x3d&quot;+c.toGMTString();document.cookie=a+&quot;\x3d&quot;+b+c+&quot;; path\x3d/; &quot;};this.check=function(){var a=this.get(f);if(a)a=a.split(&quot;:&quot;);else if(100!=e)&quot;v&quot;==g&amp;&amp;(e=Math.random()>=
e/100?0:100),a=[g,e,0],this.set(f,a.join(&quot;:&quot;));else return!0;var b=a[1];if(100==b)return!0;switch(a[0]){case &quot;v&quot;:return!1;case &quot;r&quot;:return b=a[2]%Math.floor(100/b),a[2]++,this.set(f,a.join(&quot;:&quot;)),!b}return!0};this.go=function(){if(this.check()){var a=document.createElement(&quot;script&quot;);a.type=&quot;text/javascript&quot;;a.src=h;document.body&amp;&amp;document.body.appendChild(a)}};this.start=function(){var a=this;&quot;complete&quot;!==document.readyState?window.addEventListener?window.addEventListener(&quot;load&quot;,function(){a.go()},
!1):window.attachEvent&amp;&amp;window.attachEvent(&quot;onload&quot;,function(){a.go()}):a.go()}};try{(new l(100,&quot;r&quot;,&quot;QSI_S_ZN_7O52igS32q4g9qm&quot;,&quot;https://zn7o52igs32q4g9qm-greatmoments.siteintercept.qualtrics.com/SIE/?Q_ZID\x3dZN_7O52igS32q4g9qm&quot;)).start()}catch(e){}})();
(new MutationObserver(function(){var a=sessionStorage.getItem(&quot;prevUrl&quot;),b=document.location.href;a!==b&amp;&amp;(sessionStorage.setItem(&quot;prevUrl&quot;,b),window.referrer=a)})).observe(document.querySelector(&quot;body&quot;),{childList:!0,subtree:!0});
!function(b,e,f,g,a,c,d){b.fbq||(a=b.fbq=function(){a.callMethod?a.callMethod.apply(a,arguments):a.queue.push(arguments)},b._fbq||(b._fbq=a),a.push=a,a.loaded=!0,a.version=&quot;2.0&quot;,a.queue=[],c=e.createElement(f),c.async=!0,c.src=g,d=e.getElementsByTagName(f)[0],d.parentNode.insertBefore(c,d))}(window,document,&quot;script&quot;,&quot;https://connect.facebook.net/en_US/fbevents.js&quot;);fbq(&quot;init&quot;,&quot;270495503980976&quot;);fbq(&quot;track&quot;,&quot;PageView&quot;);
&lt;img height=&quot;1&quot; width=&quot;1&quot; style=&quot;display:none&quot; src=&quot;https://www.facebook.com/tr?id=270495503980976&amp;amp;ev=PageView&amp;amp;noscript=1&quot;>
.QSIFeedbackButton div,.QSIFeedbackButton dl,.QSIFeedbackButton dt,.QSIFeedbackButton dd,.QSIFeedbackButton ul,.QSIFeedbackButton ol,.QSIFeedbackButton li,.QSIFeedbackButton h1,.QSIFeedbackButton h2,.QSIFeedbackButton h3,.QSIFeedbackButton h4,.QSIFeedbackButton h5,.QSIFeedbackButton h6,.QSIFeedbackButton span,.QSIFeedbackButton pre,.QSIFeedbackButton form,.QSIFeedbackButton fieldset,.QSIFeedbackButton textarea,.QSIFeedbackButton p,.QSIFeedbackButton blockquote,.QSIFeedbackButton tr,.QSIFeedbackButton th,.QSIFeedbackButton td{ margin: 0; padding: 0;background-color: transparent; border: 0; font-size: 12px; line-height: normal; vertical-align:baseline; box-shadow: none; }.QSIFeedbackButton img{ height: auto; width: auto; margin: 0; padding: 0 }.QSIFeedbackButton ul,.QSIFeedbackButton ol{ margin: 12px 0; padding-left: 40px; }.QSIFeedbackButton ul li{ list-style-type: disc; }.QSIFeedbackButton ol li{ list-style-type: decimal; }.QSIFeedbackButton .scrollable{ -webkit-overflow-scrolling: touch; }.QSIFeedbackButton table{ border-collapse: collapse; border-spacing: 0; }.QSIFeedbackButton table td{ padding: 2px; }.QSIFeedbackButton iframe{ max-height: none; }.QSIFeedbackButton *{ box-sizing: content-box; }Feedback
!function(b,e,f,g,a,c,d){b.fbq||(a=b.fbq=function(){a.callMethod?a.callMethod.apply(a,arguments):a.queue.push(arguments)},b._fbq||(b._fbq=a),a.push=a,a.loaded=!0,a.version=&quot;2.0&quot;,a.queue=[],c=e.createElement(f),c.async=!0,c.src=g,d=e.getElementsByTagName(f)[0],d.parentNode.insertBefore(c,d))}(window,document,&quot;script&quot;,&quot;https://connect.facebook.net/en_US/fbevents.js&quot;);fbq(&quot;init&quot;,&quot;270495503980976&quot;);fbq(&quot;track&quot;,&quot;PageView&quot;);
&lt;img height=&quot;1&quot; width=&quot;1&quot; style=&quot;display:none&quot; src=&quot;https://www.facebook.com/tr?id=270495503980976&amp;amp;ev=PageView&amp;amp;noscript=1&quot;>

!function(b,e,f,g,a,c,d){b.fbq||(a=b.fbq=function(){a.callMethod?a.callMethod.apply(a,arguments):a.queue.push(arguments)},b._fbq||(b._fbq=a),a.push=a,a.loaded=!0,a.version=&quot;2.0&quot;,a.queue=[],c=e.createElement(f),c.async=!0,c.src=g,d=e.getElementsByTagName(f)[0],d.parentNode.insertBefore(c,d))}(window,document,&quot;script&quot;,&quot;https://connect.facebook.net/en_US/fbevents.js&quot;);fbq(&quot;init&quot;,&quot;270495503980976&quot;);fbq(&quot;track&quot;,&quot;PageView&quot;);
&lt;img height=&quot;1&quot; width=&quot;1&quot; style=&quot;display:none&quot; src=&quot;https://www.facebook.com/tr?id=270495503980976&amp;amp;ev=PageView&amp;amp;noscript=1&quot;>

      
        
          
        
        
        
        
        
        
        
        
        
          
          
        
        
          
          
          
          
        
      
    
!function(b,e,f,g,a,c,d){b.fbq||(a=b.fbq=function(){a.callMethod?a.callMethod.apply(a,arguments):a.queue.push(arguments)},b._fbq||(b._fbq=a),a.push=a,a.loaded=!0,a.version=&quot;2.0&quot;,a.queue=[],c=e.createElement(f),c.async=!0,c.src=g,d=e.getElementsByTagName(f)[0],d.parentNode.insertBefore(c,d))}(window,document,&quot;script&quot;,&quot;https://connect.facebook.net/en_US/fbevents.js&quot;);fbq(&quot;init&quot;,&quot;270495503980976&quot;);fbq(&quot;track&quot;,&quot;ViewContent&quot;);
&lt;img height=&quot;1&quot; width=&quot;1&quot; style=&quot;display:none&quot; src=&quot;https://www.facebook.com/tr?id=270495503980976&amp;amp;ev=PageView&amp;amp;noscript=1&quot;>
Shopping Bag (1)Lee Lace Dress AED 650.00 Size: SQUANTITY: 1 Remove   Total  AED 650.00 CHECKOUTContinue Shopping
!function(b,e,f,g,a,c,d){b.fbq||(a=b.fbq=function(){a.callMethod?a.callMethod.apply(a,arguments):a.queue.push(arguments)},b._fbq||(b._fbq=a),a.push=a,a.loaded=!0,a.version=&quot;2.0&quot;,a.queue=[],c=e.createElement(f),c.async=!0,c.src=g,d=e.getElementsByTagName(f)[0],d.parentNode.insertBefore(c,d))}(window,document,&quot;script&quot;,&quot;https://connect.facebook.net/en_US/fbevents.js&quot;);fbq(&quot;init&quot;,&quot;270495503980976&quot;);fbq(&quot;track&quot;,&quot;AddToCart&quot;,{productName:google_tag_manager[&quot;GTM-KSKPDRH&quot;].macro(80),productId:google_tag_manager[&quot;GTM-KSKPDRH&quot;].macro(83),market:&quot;AE&quot;});
&lt;img height=&quot;1&quot; width=&quot;1&quot; style=&quot;display:none&quot; src=&quot;https://www.facebook.com/tr?id=270495503980976&amp;amp;ev=PageView&amp;amp;noscript=1&quot;>
id(&quot;katalon-rec_elementInfoDiv&quot;)</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;xs-up:bgc=body xs-up.fa-times:icon-before=cross state-loading modal-open&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//body</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//body[(text() = concat(&quot;
    
      ALLSAINTS
      
    
        
    
SearchSaleWomenWomenClothingDressesTops &amp; ShirtsT-ShirtsSkirts &amp; ShortsSwimwearLeather JacketsJeansTrousers &amp; LeggingsSweatshirts &amp; HoodiesCoats &amp; JacketsKnitwearNational DayShoes And AccessoriesAll ShoesAll AccessoriesFragranceHandbagsCard Holders &amp; WalletsFace MasksShop DressesFree same day delivery for orders before 7PMMenSearchSearch
            
              
            
            
          
            
              
            
            
          ALLSAINTSSign InWishlistSomething catch your eye?Sign in to see items you may have added using another computer or device.Sign inBag (1)Lee Lace Dress AED 650.00 Size: SQUANTITY: 1 Remove Sign in to see items you may have added using another computer or device.CHECKOUTENJOY 20% OFF YOUR FIRST PURCHASE - USE CODE HELLO20SHOP NOWHomeHomeWomenWomenClothingClothingLee Lace DressPreviousBack to DressesNextTap To ZoomTap To ZoomTap To ZoomTap To ZoomTap To ZoomTap To ZoomPreviousBack to DressesNextLee Lace DressSKU: UPV0830016AED 650.00
  
    
      or 4 interest-free payments of 162.50 AED.
      Learn more
      
    

    
    
  

            new TabbyPromo({
                selector: &quot; , &quot;'&quot; , &quot;#TabbyPromo&quot; , &quot;'&quot; , &quot;,
                currency: &quot; , &quot;'&quot; , &quot;AED&quot; , &quot;'&quot; , &quot;,
                price: &quot; , &quot;'&quot; , &quot;650&quot; , &quot;'&quot; , &quot;,
                installmentsCount: 4,
                lang: &quot; , &quot;'&quot; , &quot;en&quot; , &quot;'&quot; , &quot;,
            }); Selected option is no longer available. Color: BlackBlackSize: S X XS S S M M L LAdd to BagAdd to favoritesEarn 65 points NotesDress it up. The Lee Lace Dress. It&quot; , &quot;'&quot; , &quot;s an off-duty essential. With a sweatshirt body. And lace-trimmed hem.  Instant layerPulloverShort lengthLong sleeveCrew neckLace trim at the hemModel is 5&quot; , &quot;'&quot; , &quot;9&quot;/177cm and wears a size Medium DetailsSHARERECENTLY VIEWEDLee Lace DressUPV0830016AED 650.00Add to BagNew to AllSaints? Sign up for 20% off full-price styles in your first order. Email Address  SEND INFORMATIONContact UsReturns &amp; ExchangeShipping and FAQsSize GuideTrack OrderTerms &amp; ConditionsPrivacy PolicySite MapFOLLOW USInstagramCOPYRIGHT © 2021 ALLSAINTS ALL RIGHTS RESERVED*ORDERS BEFORE 7PM
    
      Please enable JavaScript to continue using this application.
    
  


(function(){var l=function(e,g,f,h){this.get=function(a){a+=&quot;\x3d&quot;;for(var b=document.cookie.split(&quot;;&quot;),c=0,k=b.length;c&lt;k;c++){for(var d=b[c];&quot; &quot;==d.charAt(0);)d=d.substring(1,d.length);if(0==d.indexOf(a))return d.substring(a.length,d.length)}return null};this.set=function(a,b){var c=new Date;c.setTime(c.getTime()+6048E5);c=&quot;; expires\x3d&quot;+c.toGMTString();document.cookie=a+&quot;\x3d&quot;+b+c+&quot;; path\x3d/; &quot;};this.check=function(){var a=this.get(f);if(a)a=a.split(&quot;:&quot;);else if(100!=e)&quot;v&quot;==g&amp;&amp;(e=Math.random()>=
e/100?0:100),a=[g,e,0],this.set(f,a.join(&quot;:&quot;));else return!0;var b=a[1];if(100==b)return!0;switch(a[0]){case &quot;v&quot;:return!1;case &quot;r&quot;:return b=a[2]%Math.floor(100/b),a[2]++,this.set(f,a.join(&quot;:&quot;)),!b}return!0};this.go=function(){if(this.check()){var a=document.createElement(&quot;script&quot;);a.type=&quot;text/javascript&quot;;a.src=h;document.body&amp;&amp;document.body.appendChild(a)}};this.start=function(){var a=this;&quot;complete&quot;!==document.readyState?window.addEventListener?window.addEventListener(&quot;load&quot;,function(){a.go()},
!1):window.attachEvent&amp;&amp;window.attachEvent(&quot;onload&quot;,function(){a.go()}):a.go()}};try{(new l(100,&quot;r&quot;,&quot;QSI_S_ZN_7O52igS32q4g9qm&quot;,&quot;https://zn7o52igs32q4g9qm-greatmoments.siteintercept.qualtrics.com/SIE/?Q_ZID\x3dZN_7O52igS32q4g9qm&quot;)).start()}catch(e){}})();
(new MutationObserver(function(){var a=sessionStorage.getItem(&quot;prevUrl&quot;),b=document.location.href;a!==b&amp;&amp;(sessionStorage.setItem(&quot;prevUrl&quot;,b),window.referrer=a)})).observe(document.querySelector(&quot;body&quot;),{childList:!0,subtree:!0});
!function(b,e,f,g,a,c,d){b.fbq||(a=b.fbq=function(){a.callMethod?a.callMethod.apply(a,arguments):a.queue.push(arguments)},b._fbq||(b._fbq=a),a.push=a,a.loaded=!0,a.version=&quot;2.0&quot;,a.queue=[],c=e.createElement(f),c.async=!0,c.src=g,d=e.getElementsByTagName(f)[0],d.parentNode.insertBefore(c,d))}(window,document,&quot;script&quot;,&quot;https://connect.facebook.net/en_US/fbevents.js&quot;);fbq(&quot;init&quot;,&quot;270495503980976&quot;);fbq(&quot;track&quot;,&quot;PageView&quot;);
&lt;img height=&quot;1&quot; width=&quot;1&quot; style=&quot;display:none&quot; src=&quot;https://www.facebook.com/tr?id=270495503980976&amp;amp;ev=PageView&amp;amp;noscript=1&quot;>
.QSIFeedbackButton div,.QSIFeedbackButton dl,.QSIFeedbackButton dt,.QSIFeedbackButton dd,.QSIFeedbackButton ul,.QSIFeedbackButton ol,.QSIFeedbackButton li,.QSIFeedbackButton h1,.QSIFeedbackButton h2,.QSIFeedbackButton h3,.QSIFeedbackButton h4,.QSIFeedbackButton h5,.QSIFeedbackButton h6,.QSIFeedbackButton span,.QSIFeedbackButton pre,.QSIFeedbackButton form,.QSIFeedbackButton fieldset,.QSIFeedbackButton textarea,.QSIFeedbackButton p,.QSIFeedbackButton blockquote,.QSIFeedbackButton tr,.QSIFeedbackButton th,.QSIFeedbackButton td{ margin: 0; padding: 0;background-color: transparent; border: 0; font-size: 12px; line-height: normal; vertical-align:baseline; box-shadow: none; }.QSIFeedbackButton img{ height: auto; width: auto; margin: 0; padding: 0 }.QSIFeedbackButton ul,.QSIFeedbackButton ol{ margin: 12px 0; padding-left: 40px; }.QSIFeedbackButton ul li{ list-style-type: disc; }.QSIFeedbackButton ol li{ list-style-type: decimal; }.QSIFeedbackButton .scrollable{ -webkit-overflow-scrolling: touch; }.QSIFeedbackButton table{ border-collapse: collapse; border-spacing: 0; }.QSIFeedbackButton table td{ padding: 2px; }.QSIFeedbackButton iframe{ max-height: none; }.QSIFeedbackButton *{ box-sizing: content-box; }Feedback
!function(b,e,f,g,a,c,d){b.fbq||(a=b.fbq=function(){a.callMethod?a.callMethod.apply(a,arguments):a.queue.push(arguments)},b._fbq||(b._fbq=a),a.push=a,a.loaded=!0,a.version=&quot;2.0&quot;,a.queue=[],c=e.createElement(f),c.async=!0,c.src=g,d=e.getElementsByTagName(f)[0],d.parentNode.insertBefore(c,d))}(window,document,&quot;script&quot;,&quot;https://connect.facebook.net/en_US/fbevents.js&quot;);fbq(&quot;init&quot;,&quot;270495503980976&quot;);fbq(&quot;track&quot;,&quot;PageView&quot;);
&lt;img height=&quot;1&quot; width=&quot;1&quot; style=&quot;display:none&quot; src=&quot;https://www.facebook.com/tr?id=270495503980976&amp;amp;ev=PageView&amp;amp;noscript=1&quot;>

!function(b,e,f,g,a,c,d){b.fbq||(a=b.fbq=function(){a.callMethod?a.callMethod.apply(a,arguments):a.queue.push(arguments)},b._fbq||(b._fbq=a),a.push=a,a.loaded=!0,a.version=&quot;2.0&quot;,a.queue=[],c=e.createElement(f),c.async=!0,c.src=g,d=e.getElementsByTagName(f)[0],d.parentNode.insertBefore(c,d))}(window,document,&quot;script&quot;,&quot;https://connect.facebook.net/en_US/fbevents.js&quot;);fbq(&quot;init&quot;,&quot;270495503980976&quot;);fbq(&quot;track&quot;,&quot;PageView&quot;);
&lt;img height=&quot;1&quot; width=&quot;1&quot; style=&quot;display:none&quot; src=&quot;https://www.facebook.com/tr?id=270495503980976&amp;amp;ev=PageView&amp;amp;noscript=1&quot;>

      
        
          
        
        
        
        
        
        
        
        
        
          
          
        
        
          
          
          
          
        
      
    
!function(b,e,f,g,a,c,d){b.fbq||(a=b.fbq=function(){a.callMethod?a.callMethod.apply(a,arguments):a.queue.push(arguments)},b._fbq||(b._fbq=a),a.push=a,a.loaded=!0,a.version=&quot;2.0&quot;,a.queue=[],c=e.createElement(f),c.async=!0,c.src=g,d=e.getElementsByTagName(f)[0],d.parentNode.insertBefore(c,d))}(window,document,&quot;script&quot;,&quot;https://connect.facebook.net/en_US/fbevents.js&quot;);fbq(&quot;init&quot;,&quot;270495503980976&quot;);fbq(&quot;track&quot;,&quot;ViewContent&quot;);
&lt;img height=&quot;1&quot; width=&quot;1&quot; style=&quot;display:none&quot; src=&quot;https://www.facebook.com/tr?id=270495503980976&amp;amp;ev=PageView&amp;amp;noscript=1&quot;>
Shopping Bag (1)Lee Lace Dress AED 650.00 Size: SQUANTITY: 1 Remove   Total  AED 650.00 CHECKOUTContinue Shopping
!function(b,e,f,g,a,c,d){b.fbq||(a=b.fbq=function(){a.callMethod?a.callMethod.apply(a,arguments):a.queue.push(arguments)},b._fbq||(b._fbq=a),a.push=a,a.loaded=!0,a.version=&quot;2.0&quot;,a.queue=[],c=e.createElement(f),c.async=!0,c.src=g,d=e.getElementsByTagName(f)[0],d.parentNode.insertBefore(c,d))}(window,document,&quot;script&quot;,&quot;https://connect.facebook.net/en_US/fbevents.js&quot;);fbq(&quot;init&quot;,&quot;270495503980976&quot;);fbq(&quot;track&quot;,&quot;AddToCart&quot;,{productName:google_tag_manager[&quot;GTM-KSKPDRH&quot;].macro(80),productId:google_tag_manager[&quot;GTM-KSKPDRH&quot;].macro(83),market:&quot;AE&quot;});
&lt;img height=&quot;1&quot; width=&quot;1&quot; style=&quot;display:none&quot; src=&quot;https://www.facebook.com/tr?id=270495503980976&amp;amp;ev=PageView&amp;amp;noscript=1&quot;>
id(&quot;katalon-rec_elementInfoDiv&quot;)&quot;) or . = concat(&quot;
    
      ALLSAINTS
      
    
        
    
SearchSaleWomenWomenClothingDressesTops &amp; ShirtsT-ShirtsSkirts &amp; ShortsSwimwearLeather JacketsJeansTrousers &amp; LeggingsSweatshirts &amp; HoodiesCoats &amp; JacketsKnitwearNational DayShoes And AccessoriesAll ShoesAll AccessoriesFragranceHandbagsCard Holders &amp; WalletsFace MasksShop DressesFree same day delivery for orders before 7PMMenSearchSearch
            
              
            
            
          
            
              
            
            
          ALLSAINTSSign InWishlistSomething catch your eye?Sign in to see items you may have added using another computer or device.Sign inBag (1)Lee Lace Dress AED 650.00 Size: SQUANTITY: 1 Remove Sign in to see items you may have added using another computer or device.CHECKOUTENJOY 20% OFF YOUR FIRST PURCHASE - USE CODE HELLO20SHOP NOWHomeHomeWomenWomenClothingClothingLee Lace DressPreviousBack to DressesNextTap To ZoomTap To ZoomTap To ZoomTap To ZoomTap To ZoomTap To ZoomPreviousBack to DressesNextLee Lace DressSKU: UPV0830016AED 650.00
  
    
      or 4 interest-free payments of 162.50 AED.
      Learn more
      
    

    
    
  

            new TabbyPromo({
                selector: &quot; , &quot;'&quot; , &quot;#TabbyPromo&quot; , &quot;'&quot; , &quot;,
                currency: &quot; , &quot;'&quot; , &quot;AED&quot; , &quot;'&quot; , &quot;,
                price: &quot; , &quot;'&quot; , &quot;650&quot; , &quot;'&quot; , &quot;,
                installmentsCount: 4,
                lang: &quot; , &quot;'&quot; , &quot;en&quot; , &quot;'&quot; , &quot;,
            }); Selected option is no longer available. Color: BlackBlackSize: S X XS S S M M L LAdd to BagAdd to favoritesEarn 65 points NotesDress it up. The Lee Lace Dress. It&quot; , &quot;'&quot; , &quot;s an off-duty essential. With a sweatshirt body. And lace-trimmed hem.  Instant layerPulloverShort lengthLong sleeveCrew neckLace trim at the hemModel is 5&quot; , &quot;'&quot; , &quot;9&quot;/177cm and wears a size Medium DetailsSHARERECENTLY VIEWEDLee Lace DressUPV0830016AED 650.00Add to BagNew to AllSaints? Sign up for 20% off full-price styles in your first order. Email Address  SEND INFORMATIONContact UsReturns &amp; ExchangeShipping and FAQsSize GuideTrack OrderTerms &amp; ConditionsPrivacy PolicySite MapFOLLOW USInstagramCOPYRIGHT © 2021 ALLSAINTS ALL RIGHTS RESERVED*ORDERS BEFORE 7PM
    
      Please enable JavaScript to continue using this application.
    
  


(function(){var l=function(e,g,f,h){this.get=function(a){a+=&quot;\x3d&quot;;for(var b=document.cookie.split(&quot;;&quot;),c=0,k=b.length;c&lt;k;c++){for(var d=b[c];&quot; &quot;==d.charAt(0);)d=d.substring(1,d.length);if(0==d.indexOf(a))return d.substring(a.length,d.length)}return null};this.set=function(a,b){var c=new Date;c.setTime(c.getTime()+6048E5);c=&quot;; expires\x3d&quot;+c.toGMTString();document.cookie=a+&quot;\x3d&quot;+b+c+&quot;; path\x3d/; &quot;};this.check=function(){var a=this.get(f);if(a)a=a.split(&quot;:&quot;);else if(100!=e)&quot;v&quot;==g&amp;&amp;(e=Math.random()>=
e/100?0:100),a=[g,e,0],this.set(f,a.join(&quot;:&quot;));else return!0;var b=a[1];if(100==b)return!0;switch(a[0]){case &quot;v&quot;:return!1;case &quot;r&quot;:return b=a[2]%Math.floor(100/b),a[2]++,this.set(f,a.join(&quot;:&quot;)),!b}return!0};this.go=function(){if(this.check()){var a=document.createElement(&quot;script&quot;);a.type=&quot;text/javascript&quot;;a.src=h;document.body&amp;&amp;document.body.appendChild(a)}};this.start=function(){var a=this;&quot;complete&quot;!==document.readyState?window.addEventListener?window.addEventListener(&quot;load&quot;,function(){a.go()},
!1):window.attachEvent&amp;&amp;window.attachEvent(&quot;onload&quot;,function(){a.go()}):a.go()}};try{(new l(100,&quot;r&quot;,&quot;QSI_S_ZN_7O52igS32q4g9qm&quot;,&quot;https://zn7o52igs32q4g9qm-greatmoments.siteintercept.qualtrics.com/SIE/?Q_ZID\x3dZN_7O52igS32q4g9qm&quot;)).start()}catch(e){}})();
(new MutationObserver(function(){var a=sessionStorage.getItem(&quot;prevUrl&quot;),b=document.location.href;a!==b&amp;&amp;(sessionStorage.setItem(&quot;prevUrl&quot;,b),window.referrer=a)})).observe(document.querySelector(&quot;body&quot;),{childList:!0,subtree:!0});
!function(b,e,f,g,a,c,d){b.fbq||(a=b.fbq=function(){a.callMethod?a.callMethod.apply(a,arguments):a.queue.push(arguments)},b._fbq||(b._fbq=a),a.push=a,a.loaded=!0,a.version=&quot;2.0&quot;,a.queue=[],c=e.createElement(f),c.async=!0,c.src=g,d=e.getElementsByTagName(f)[0],d.parentNode.insertBefore(c,d))}(window,document,&quot;script&quot;,&quot;https://connect.facebook.net/en_US/fbevents.js&quot;);fbq(&quot;init&quot;,&quot;270495503980976&quot;);fbq(&quot;track&quot;,&quot;PageView&quot;);
&lt;img height=&quot;1&quot; width=&quot;1&quot; style=&quot;display:none&quot; src=&quot;https://www.facebook.com/tr?id=270495503980976&amp;amp;ev=PageView&amp;amp;noscript=1&quot;>
.QSIFeedbackButton div,.QSIFeedbackButton dl,.QSIFeedbackButton dt,.QSIFeedbackButton dd,.QSIFeedbackButton ul,.QSIFeedbackButton ol,.QSIFeedbackButton li,.QSIFeedbackButton h1,.QSIFeedbackButton h2,.QSIFeedbackButton h3,.QSIFeedbackButton h4,.QSIFeedbackButton h5,.QSIFeedbackButton h6,.QSIFeedbackButton span,.QSIFeedbackButton pre,.QSIFeedbackButton form,.QSIFeedbackButton fieldset,.QSIFeedbackButton textarea,.QSIFeedbackButton p,.QSIFeedbackButton blockquote,.QSIFeedbackButton tr,.QSIFeedbackButton th,.QSIFeedbackButton td{ margin: 0; padding: 0;background-color: transparent; border: 0; font-size: 12px; line-height: normal; vertical-align:baseline; box-shadow: none; }.QSIFeedbackButton img{ height: auto; width: auto; margin: 0; padding: 0 }.QSIFeedbackButton ul,.QSIFeedbackButton ol{ margin: 12px 0; padding-left: 40px; }.QSIFeedbackButton ul li{ list-style-type: disc; }.QSIFeedbackButton ol li{ list-style-type: decimal; }.QSIFeedbackButton .scrollable{ -webkit-overflow-scrolling: touch; }.QSIFeedbackButton table{ border-collapse: collapse; border-spacing: 0; }.QSIFeedbackButton table td{ padding: 2px; }.QSIFeedbackButton iframe{ max-height: none; }.QSIFeedbackButton *{ box-sizing: content-box; }Feedback
!function(b,e,f,g,a,c,d){b.fbq||(a=b.fbq=function(){a.callMethod?a.callMethod.apply(a,arguments):a.queue.push(arguments)},b._fbq||(b._fbq=a),a.push=a,a.loaded=!0,a.version=&quot;2.0&quot;,a.queue=[],c=e.createElement(f),c.async=!0,c.src=g,d=e.getElementsByTagName(f)[0],d.parentNode.insertBefore(c,d))}(window,document,&quot;script&quot;,&quot;https://connect.facebook.net/en_US/fbevents.js&quot;);fbq(&quot;init&quot;,&quot;270495503980976&quot;);fbq(&quot;track&quot;,&quot;PageView&quot;);
&lt;img height=&quot;1&quot; width=&quot;1&quot; style=&quot;display:none&quot; src=&quot;https://www.facebook.com/tr?id=270495503980976&amp;amp;ev=PageView&amp;amp;noscript=1&quot;>

!function(b,e,f,g,a,c,d){b.fbq||(a=b.fbq=function(){a.callMethod?a.callMethod.apply(a,arguments):a.queue.push(arguments)},b._fbq||(b._fbq=a),a.push=a,a.loaded=!0,a.version=&quot;2.0&quot;,a.queue=[],c=e.createElement(f),c.async=!0,c.src=g,d=e.getElementsByTagName(f)[0],d.parentNode.insertBefore(c,d))}(window,document,&quot;script&quot;,&quot;https://connect.facebook.net/en_US/fbevents.js&quot;);fbq(&quot;init&quot;,&quot;270495503980976&quot;);fbq(&quot;track&quot;,&quot;PageView&quot;);
&lt;img height=&quot;1&quot; width=&quot;1&quot; style=&quot;display:none&quot; src=&quot;https://www.facebook.com/tr?id=270495503980976&amp;amp;ev=PageView&amp;amp;noscript=1&quot;>

      
        
          
        
        
        
        
        
        
        
        
        
          
          
        
        
          
          
          
          
        
      
    
!function(b,e,f,g,a,c,d){b.fbq||(a=b.fbq=function(){a.callMethod?a.callMethod.apply(a,arguments):a.queue.push(arguments)},b._fbq||(b._fbq=a),a.push=a,a.loaded=!0,a.version=&quot;2.0&quot;,a.queue=[],c=e.createElement(f),c.async=!0,c.src=g,d=e.getElementsByTagName(f)[0],d.parentNode.insertBefore(c,d))}(window,document,&quot;script&quot;,&quot;https://connect.facebook.net/en_US/fbevents.js&quot;);fbq(&quot;init&quot;,&quot;270495503980976&quot;);fbq(&quot;track&quot;,&quot;ViewContent&quot;);
&lt;img height=&quot;1&quot; width=&quot;1&quot; style=&quot;display:none&quot; src=&quot;https://www.facebook.com/tr?id=270495503980976&amp;amp;ev=PageView&amp;amp;noscript=1&quot;>
Shopping Bag (1)Lee Lace Dress AED 650.00 Size: SQUANTITY: 1 Remove   Total  AED 650.00 CHECKOUTContinue Shopping
!function(b,e,f,g,a,c,d){b.fbq||(a=b.fbq=function(){a.callMethod?a.callMethod.apply(a,arguments):a.queue.push(arguments)},b._fbq||(b._fbq=a),a.push=a,a.loaded=!0,a.version=&quot;2.0&quot;,a.queue=[],c=e.createElement(f),c.async=!0,c.src=g,d=e.getElementsByTagName(f)[0],d.parentNode.insertBefore(c,d))}(window,document,&quot;script&quot;,&quot;https://connect.facebook.net/en_US/fbevents.js&quot;);fbq(&quot;init&quot;,&quot;270495503980976&quot;);fbq(&quot;track&quot;,&quot;AddToCart&quot;,{productName:google_tag_manager[&quot;GTM-KSKPDRH&quot;].macro(80),productId:google_tag_manager[&quot;GTM-KSKPDRH&quot;].macro(83),market:&quot;AE&quot;});
&lt;img height=&quot;1&quot; width=&quot;1&quot; style=&quot;display:none&quot; src=&quot;https://www.facebook.com/tr?id=270495503980976&amp;amp;ev=PageView&amp;amp;noscript=1&quot;>
id(&quot;katalon-rec_elementInfoDiv&quot;)&quot;))]</value>
   </webElementXpaths>
</WebElementEntity>
