<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_Add to Bag (1)</name>
   <tag></tag>
   <elementGuidId>d7dfe714-52bc-4978-b867-53a0e8a33f29</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>button.btn-add-to-cart</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='AddToCart']/div/div/div/button</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>button</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>btn-add-to-cart</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Add to Bag</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;AddToCart&quot;)/div[@class=&quot;leo-product-add-to-cart-component leo-product-add-to-cart-component-product-add-to-cart-btn-beta xs-up&lt;&lt;.selected-combination-disabled:d=none md-down:pos-align=bottom-stretch md-down:pos=fix! md-down:px=(1.25rem) md-down:pt=6 md-down:pb=(0.66rem) md-down:z=3 md-down:linear-gradient=(transparent,white|5.9rem) xs-up.form-group:flx-dir=col xs-up.btn-add-to-cart:btn=dark lg-up.btn-add-to-cart:btn=gamma xs-up.btn-add-to-cart:btn-size=medium! xs-up.btn-add-to-cart:fw=regular! xs-up.btn-add-to-cart:hover:btn=mid xs-up.btn-add-to-cart:w=100 xs-up.btn-add-to-cart:h=(4.17rem) md-down.btn-add-to-cart:fc=light xs-up.btn-add-to-cart:ls=.16! lg-up.btn-add-to-cart:h=(3.59rem) lg-up.btn-add-to-cart:w=(16.67rem) lg-up.btn-add-to-cart:mr=2 xs-up.input-group:mr=3 product-add-to-cart-btn-beta&quot;]/div[1]/div[@class=&quot;form-group&quot;]/button[@class=&quot;btn-add-to-cart&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='AddToCart']/div/div/div/button</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='L'])[2]/following::button[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='L'])[1]/following::button[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Add to favorites'])[1]/preceding::button[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Earn 65 points'])[1]/preceding::button[2]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Add to Bag']/parent::*</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[6]/div/div/div/div/div/button</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//button[(text() = 'Add to Bag' or . = 'Add to Bag')]</value>
   </webElementXpaths>
</WebElementEntity>
