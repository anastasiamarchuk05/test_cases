<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_reg. AED 400.00</name>
   <tag></tag>
   <elementGuidId>d8ebae1d-3929-48ca-88a4-ee3fbfa8dbd1</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='undefined']/div/div/div[2]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.crossed-price</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>crossed-price</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>reg. AED 400.00</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;ProductIntroComponent&quot;)/div[@class=&quot;leo-product-intro-component leo-product-intro-component-product-intro-component-default product-intro-component-default default&quot;]/div[1]/div[@class=&quot;product-price&quot;]/div[@id=&quot;undefined&quot;]/div[@class=&quot;leo-product-price-component leo-product-price-component-product-price-beta xs-up&lt;&lt;.list-view>>.price:fs=(1.333rem) xs-up.price:fs=p2 md-up.price:fs=p1 xs-up.price:fw=normal xs-up.price.state-cross:fc=danger xs-up&lt;&lt;.container-grid>>.price:mb=1 xs-up&lt;&lt;.list-view>>.price:mb=0 xs-up.crossed-price:fc=black-70 xs-up&lt;&lt;.selected-combination-disabled:d=none xs-up:mb=6 xs-up[leo-product-price]:flx-row-align=bottom-left xs-up[leo-product-price]:lh=1 xs-up.price:mr=2 xs-up.crossed-price:mt=3 xs-up.crossed-price:fs=p3 product-price-beta&quot;]/div[1]/div[@class=&quot;crossed-price&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='undefined']/div/div/div[2]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sale AED 305.00'])[1]/following::div[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='SKU: UPV0812926'])[1]/following::div[6]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='or 4 interest-free payments of 76.25 AED.'])[1]/preceding::div[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Selected option is no longer available.'])[1]/preceding::div[10]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='reg. AED 400.00']/parent::*</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[4]/div/div/div/div[2]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'reg. AED 400.00' or . = 'reg. AED 400.00')]</value>
   </webElementXpaths>
</WebElementEntity>
