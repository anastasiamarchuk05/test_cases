<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_On Sale</name>
   <tag></tag>
   <elementGuidId>e5bc4b5b-06cc-4c99-9a85-af9dacc52aa7</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='undefined']/div/div/div</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.badge</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>badge</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>On Sale</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;ProductIntroComponent&quot;)/div[@class=&quot;leo-product-intro-component leo-product-intro-component-product-intro-component-default product-intro-component-default default&quot;]/div[1]/div[@class=&quot;product-badges&quot;]/div[@id=&quot;undefined&quot;]/div[@class=&quot;leo-product-badges-component leo-product-badges-component-product-badges-beta xs-up[leo-product-badges]:flx-row-align=center-left xs-up[leo-product-badges]:flx-wrap=yes xs-up.badge:flx-row-align=center-left xs-up.badge:mr=(2px) xs-up:txt-case=upper xs-up:fs=p3 md-up:fs=p2 xs-up:ff=alpha xs-up:fc=alpha xs-up:fw=normal xs-up:pr=6 md-up.badge:mt=8 xs-up.badge:mb=3 xs-up.badge:mr=0 md-up:mb=6 xs-up.badge:not(:last-child):after:content=(|) xs-up.badge:not(:last-child):after:mx=2 xs-up.badge:not(:last-child):after:fs=p4 product-badges-beta&quot;]/div[1]/div[@class=&quot;badge&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='undefined']/div/div/div</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Next'])[2]/following::div[10]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Back to Fragrance'])[2]/following::div[10]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Flora Mortis, 100ml'])[2]/preceding::div[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='SKU: UPV0812926'])[1]/preceding::div[5]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='On Sale']/parent::*</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/div/div/div/div/div/div/div/div[2]/div[2]/div/div/div/div/div/div/div/div/div</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'On Sale' or . = 'On Sale')]</value>
   </webElementXpaths>
</WebElementEntity>
