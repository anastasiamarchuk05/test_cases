<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_AED 650.00</name>
   <tag></tag>
   <elementGuidId>7d83f30a-7d8c-4664-b4cd-587b9881ba48</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(//div[@id='undefined']/div/div/div)[2]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.price</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>price</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>AED 650.00</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;ProductIntroComponent&quot;)/div[@class=&quot;leo-product-intro-component leo-product-intro-component-product-intro-component-default product-intro-component-default default&quot;]/div[1]/div[@class=&quot;product-price&quot;]/div[@id=&quot;undefined&quot;]/div[@class=&quot;leo-product-price-component leo-product-price-component-product-price-beta xs-up&lt;&lt;.list-view>>.price:fs=(1.333rem) xs-up.price:fs=p2 md-up.price:fs=p1 xs-up.price:fw=normal xs-up.price.state-cross:fc=danger xs-up&lt;&lt;.container-grid>>.price:mb=1 xs-up&lt;&lt;.list-view>>.price:mb=0 xs-up.crossed-price:fc=black-70 xs-up&lt;&lt;.selected-combination-disabled:d=none xs-up:mb=6 xs-up[leo-product-price]:flx-row-align=bottom-left xs-up[leo-product-price]:lh=1 xs-up.price:mr=2 xs-up.crossed-price:mt=3 xs-up.crossed-price:fs=p3 product-price-beta&quot;]/div[1]/div[@class=&quot;price&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>(//div[@id='undefined']/div/div/div)[2]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='SKU: UPV0830016'])[1]/following::div[5]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Lee Lace Dress'])[2]/following::div[10]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='or 4 interest-free payments of 162.50 AED.'])[1]/preceding::div[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Selected option is no longer available.'])[1]/preceding::div[10]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='AED 650.00']/parent::*</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div/div/div/div[4]/div/div/div/div</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'AED 650.00' or . = 'AED 650.00')]</value>
   </webElementXpaths>
</WebElementEntity>
