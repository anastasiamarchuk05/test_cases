<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>iframe_Feedback_xs-upbw0 xs-upw100 xs-uphmax(90vh)</name>
   <tag></tag>
   <elementGuidId>7d7987c3-5735-488e-ac72-8884c869162d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div/iframe</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>iframe</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>xs-up:bw=0 xs-up:w=100 xs-up:hmax=(90vh)</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;xs-up:bgc=body xs-up.fa-times:icon-before=cross modal-open&quot;]/ngb-modal-window[@class=&quot;d-block fade modal show xs-up:d=block&quot;]/div[@class=&quot;modal-dialog modal-dialog-centered modal-lg&quot;]/div[@class=&quot;modal-content&quot;]/div[1]/div[@class=&quot;xs-up:hmax=(90vh) xs-up:transition=(height|250ms|ease|0s)&quot;]/iframe[@class=&quot;xs-up:bw=0 xs-up:w=100 xs-up:hmax=(90vh)&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/iframe</value>
   </webElementXpaths>
</WebElementEntity>
