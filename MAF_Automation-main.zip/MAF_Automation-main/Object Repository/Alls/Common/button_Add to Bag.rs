<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_Add to Bag</name>
   <tag></tag>
   <elementGuidId>e3d90d40-3382-49ad-bee7-04468ac2f25b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='undefined']/div/div/div/button</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>button.btn-add-to-cart</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>button</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>btn-add-to-cart</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Add to Bag</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;ProductListComponent&quot;)/div[@class=&quot;leo-product-list-component leo-product-list-component-product-grid-alpha-three-columns xs-up:product-grid:pos=rel xs-up:product-grid-col-item-inner:h=100 xs-up:ff=beta xs-up:hmin=(400px) md-up:hmin=(500px) lg-up:hmin=(700px) xs-up:product-grid-container:px=4 lg-up:product-grid-container:px=(5.5rem) lg-up:product-grid-container:wmax=100 xs-up:product-grid-row-group:mb=5 xs-up:product-grid-col-item-inner:d=flx xs-up:product-grid-col-item-inner:flx-dir=col xs-up:product-grid-col-item-inner:pos=rel xs-up:product-grid-col-item-inner:pr=0 md-up:product-grid-col-item-inner:pr=6 xs-up:product-grid-col-item-inner:pl=0 md-up:product-grid-col-item-inner:pl=0 lg-up:product-grid-col-item-inner:pl=0 xs-up.row-image+.row:mt=5 xs-up.row-image>.col-item>.col-item-inner:px=0! md-up.row-add-to-wishlist>>.col-item:hover>>.tile-add-to-wishlist:d=flx lg-up.tile-add-to-wishlist:d=none xs-up.tile-add-to-wishlist:pos-align=top-right xs-up.tile-add-to-wishlist>>.btn-wishlist:before:square=(1.333rem) xs-up.tile-add-to-wishlist:bottom=auto md-down>>.col-6>>.tile-add-to-wishlist:bottom=2 md-down>>.col-6>>.tile-add-to-wishlist:top=auto lg-up.tile-add-to-wishlist:top=n1 xs-up.tile-variant-selector-advanced>>.features-group:mb=3 xs-up.tile-variant-selected-item>>.variant-list:mb=3 xs-up.tile-name:pr=7 md-down>>.col-6>>.tile-name:pr=0 xs-up.tile-summary>>.summary:mb=3 xs-up.tile-add-to-cart:mt=auto xs-up.tile-image:d=flx xs-up.tile-image:h=100 xs-up.tile-image>div:w=100 xs-up:product-grid-alpha-two-columns lg-up:product-grid-alpha-three-columns md-down.tile-variant-selector-simple>>.size:d=none&quot;]/div[1]/div[@class=&quot;container container-grid&quot;]/div[@class=&quot;row-group&quot;]/div[@class=&quot;row row-add-to-wishlist row-badges row-name row-price row-variant-selector-simple row-add-to-cart row-stock-badge-cta&quot;]/div[@class=&quot;col-item col-4&quot;]/div[@class=&quot;col-item-inner&quot;]/div[@class=&quot;tile tile-add-to-cart&quot;]/div[@id=&quot;undefined&quot;]/div[@class=&quot;leo-product-add-to-cart-component leo-product-add-to-cart-component-product-add-to-cart-btn-alpha xs-up:mt=0 xs-up.form-group>.input-group:d=none xs-up.btn-add-to-cart:btn=white xs-up.btn-add-to-cart[disabled]:d=none xs-up.btn-add-to-cart:btn-size=medium xs-up.btn-add-to-cart:bc=alpha xs-up.btn-add-to-cart:px=0 xs-up.btn-add-to-cart:py=1 xs-up.btn-add-to-cart:bw=0 xs-up.btn-add-to-cart:fs=p4 xs-up.btn-add-to-cart:fw=medium xs-up.btn-add-to-cart:ff=alpha xs-up.input-group:mr=3 xs-up.btn-add-to-cart:pos=rel xs-up.btn-add-to-cart:icon-after=underline-left-to-right-scale xs-up.btn-add-to-cart:after:bw-bottom=(1px) xs-up.btn-add-to-cart:after:d=block xs-up.btn-add-to-cart:after:bottom=0 xs-up.btn-add-to-cart:hover:txt-underline=no xs-up.btn-add-to-cart:not([disabled]):hover:icon-after=underline-left-to-right xs-up.btn-add-to-cart[disabled]:after:opacity=60 xs-up:product-add-to-cart-btn-eta md-up:product-add-to-cart-btn-alpha&quot;]/div[1]/div[@class=&quot;form-group&quot;]/button[@class=&quot;btn-add-to-cart&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='undefined']/div/div/div/button</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Size 8'])[1]/following::button[3]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='S'])[6]/following::button[3]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Add to favorites'])[2]/preceding::button[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Hadley Epoto Silk Blend Dress'])[1]/preceding::button[2]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Add to Bag']/parent::*</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[6]/div/div/div/div/button</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//button[(text() = 'Add to Bag' or . = 'Add to Bag')]</value>
   </webElementXpaths>
</WebElementEntity>
