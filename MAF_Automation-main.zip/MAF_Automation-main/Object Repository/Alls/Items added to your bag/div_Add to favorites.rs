<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Add to favorites</name>
   <tag></tag>
   <elementGuidId>ba760098-7f8f-4297-8475-8546b8e2b116</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(//div[@id='undefined']/div/div)[7]</value>
      </entry>
      <entry>
         <key>CSS</key>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Add to favorites</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;ProductListComponent&quot;)/div[@class=&quot;leo-product-list-component leo-product-list-component-product-grid-alpha-three-columns xs-up:product-grid:pos=rel xs-up:product-grid-col-item-inner:h=100 xs-up:ff=beta xs-up:hmin=(400px) md-up:hmin=(500px) lg-up:hmin=(700px) xs-up:product-grid-container:px=4 lg-up:product-grid-container:px=(5.5rem) lg-up:product-grid-container:wmax=100 xs-up:product-grid-row-group:mb=5 xs-up:product-grid-col-item-inner:d=flx xs-up:product-grid-col-item-inner:flx-dir=col xs-up:product-grid-col-item-inner:pos=rel xs-up:product-grid-col-item-inner:pr=0 md-up:product-grid-col-item-inner:pr=6 xs-up:product-grid-col-item-inner:pl=0 md-up:product-grid-col-item-inner:pl=0 lg-up:product-grid-col-item-inner:pl=0 xs-up.row-image+.row:mt=5 xs-up.row-image>.col-item>.col-item-inner:px=0! md-up.row-add-to-wishlist>>.col-item:hover>>.tile-add-to-wishlist:d=flx lg-up.tile-add-to-wishlist:d=none xs-up.tile-add-to-wishlist:pos-align=top-right xs-up.tile-add-to-wishlist>>.btn-wishlist:before:square=(1.333rem) xs-up.tile-add-to-wishlist:bottom=auto md-down>>.col-6>>.tile-add-to-wishlist:bottom=2 md-down>>.col-6>>.tile-add-to-wishlist:top=auto lg-up.tile-add-to-wishlist:top=n1 xs-up.tile-variant-selector-advanced>>.features-group:mb=3 xs-up.tile-variant-selected-item>>.variant-list:mb=3 xs-up.tile-name:pr=7 md-down>>.col-6>>.tile-name:pr=0 xs-up.tile-summary>>.summary:mb=3 xs-up.tile-add-to-cart:mt=auto xs-up.tile-image:d=flx xs-up.tile-image:h=100 xs-up.tile-image>div:w=100 xs-up:product-grid-alpha-two-columns lg-up:product-grid-alpha-three-columns md-down.tile-variant-selector-simple>>.size:d=none&quot;]/div[1]/div[@class=&quot;container container-grid&quot;]/div[@class=&quot;row-group&quot;]/div[@class=&quot;row row-add-to-wishlist row-badges row-name row-price row-variant-selector-simple row-add-to-cart row-stock-badge-cta&quot;]/div[@class=&quot;col-item col-4&quot;]/div[@class=&quot;col-item-inner&quot;]/div[@class=&quot;tile tile-add-to-wishlist&quot;]/div[@id=&quot;undefined&quot;]/div[@class=&quot;leo-add-to-wish-list-component leo-add-to-wish-list-component-product-add-to-wishlist-btn-alpha xs-up.btn-wishlist:btn=body xs-up.btn-wishlist:br=full xs-up.btn-wishlist:square=(30px) md-up.btn-wishlist:square=(40px) xs-up.btn-wishlist:p=0 xs-up.btn-wishlist:pos=rel xs-up.btn-wishlist:right=n1! xs-up.btn-wishlist:fw=normal xs-up.btn-wishlist>>span:d=none xs-up.btn-wishlist:icon-before=heart xs-up.btn-wishlist:icon-before=heart-o xs-up.btn-wishlist:before:fs=(20px) xs-up.btn-wishlist.state-active:icon-before=heart-solid xs-up&lt;&lt;[leo-wishlist]>>.btn-wishlist.state-active:icon-before=cross md-up.btn-wishlist:hover:icon-before=heart-solid product-add-to-wishlist-btn-alpha&quot;]/div[1]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>(//div[@id='undefined']/div/div)[7]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Name (descending)'])[1]/following::div[61]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Name (ascending)'])[1]/following::div[61]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Tammy Leppo Top'])[1]/preceding::div[5]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div/div/div/div/div[2]/div/div/div/div/div/div</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'Add to favorites' or . = 'Add to favorites')]</value>
   </webElementXpaths>
</WebElementEntity>
