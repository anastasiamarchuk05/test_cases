<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Add to favorites_image</name>
   <tag></tag>
   <elementGuidId>63cd0267-4245-4df8-aac7-733c7a1a5ed5</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='EarnablePointsComponent']/div/div/div/div</value>
      </entry>
      <entry>
         <key>CSS</key>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>image-container xs-up:d=flx xs-up:w=30 xs-up:pr=3</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;EarnablePointsComponent&quot;)/div[@class=&quot;leo-earnable-points-component leo-earnable-points-component-product-earnable-points xs-up&lt;&lt;.selected-variant-option-disabled:d=none xs-up.image-container:w=(8.5rem) xs-up.image-container:flx-align-items=center xs-up.earnable-points-for-product:fs=p3 lg-up.earnable-points-for-product:fs=p1 xs-up.earnable-points-for-product:fw=semi xs-up.earnable-points-for-product:fc=burgundy xs-up.earnable-points-for-product:bc=muted xs-up.icon-info:icon-before=question-mark xs-up.icon-info:invert=(0.4) product-earnable-points&quot;]/div[1]/div[@class=&quot;share-earnable-points xs-up:d=flx xs-up:mb=3&quot;]/div[@class=&quot;image-container xs-up:d=flx xs-up:w=30 xs-up:pr=3&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='EarnablePointsComponent']/div/div/div/div</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Add to favorites'])[1]/following::div[7]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Size 34'])[1]/following::div[21]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Earn 37.5 points'])[1]/preceding::div[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Type in your email address below to get notified when it is back in stock.'])[1]/preceding::div[2]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[8]/div/div/div/div/div/div</value>
   </webElementXpaths>
</WebElementEntity>
