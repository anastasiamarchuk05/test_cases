<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Womens T-Shirts</name>
   <tag></tag>
   <elementGuidId>dc613fb3-5b2f-4a1f-8c1c-81a41472c015</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='AllsBreadcrumbComponent']/div/div/div/div/div/div/ul/li[4]/span</value>
      </entry>
      <entry>
         <key>CSS</key>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Women's T-Shirts</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;AllsBreadcrumbComponent&quot;)/div[@class=&quot;leo-breadcrumb-component leo-breadcrumb-component-breadcrumb-alpha xs-up:fs=p4 xs-up:pos=rel xs-up:z=1 xs-up.container:my=4 xs-up>>ul:list-style=none xs-up>>ul:flx-row-align=center-left xs-up>>ul:flx-wrap=yes xs-up>>li:not(:first-child):icon-before=slash-right xs-up>>li:fc=beta xs-up>>li:before:fc=dark xs-up>>li:before:px=(0.34rem) xs-up>>li[itemscope]:txt-case=upper xs-up>>a:fc=alpha xs-up>>a:hover:txt-underline=no xs-up>>h1:fs=h3 xs-up>>h1:ls=.6 xs-up>>h1:lh=(1.1) xs-up>>h1:ff=beta xs-up>>h1:fw=light xs-up>>h1:mt=5 xs-up>>h1:mb=4 xs-up>>h1:txt-align=center xs-up.static-page-template>>ul:d=none xs-up.static-page-template>>.container:wmax=normal xs-up.account-page-template:d=none xs-up.register-page-template:d=none xs-up.static-page-template-about-us:d=none xs-up.landing-page2-template:d=none xs-up.login-page-template:d=none xs-up.cart-page-template:d=none xs-up.search-results-list-page-template:d=none xs-up.content-page1-template>>h1:d=none xs-up.category-page-level1-template:d=none xs-up.error-page-template:d=none xs-up.store-finder-page-template:d=none xs-up.static-page-template-all:d=none xs-up.static-page-template-women-beta:d=none xs-up.static-page-template-men-beta:d=none xs-up.static-page-template-features:d=none xs-up.static-page-template-not-for-sale:d=none xs-up.product-list-page-template>>.container:wmax=100 xs-up.product-list-page-template>>.container:px=(1.3rem) md-up.product-list-page-template>>.container:px=(2.3rem) xs-up.static-page-template-guest-order:ff=beta xs-up.static-page-template-guest-order:py=3 xs-up.static-page-template-guest-order>>h1:ls=.4 xs-up.product-details-page-template:px=2 xs-up.static-page-template-features-denim-guide:d=none breadcrumb-alpha xs-up.product-list-page-template:d=block!&quot;]/div[1]/div[@class=&quot;product-list-page-template product-list-page-template-product-list&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-12&quot;]/ul[1]/li[4]/span[1]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='AllsBreadcrumbComponent']/div/div/div/div/div/div/ul/li[4]/span</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Clothing'])[4]/following::span[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Clothing'])[3]/following::span[2]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)=concat('Women', &quot;'&quot;, 's T-Shirts')])[2]/preceding::span[2]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='logo t-shirts'])[1]/preceding::span[2]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[4]/span</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = concat(&quot;Women&quot; , &quot;'&quot; , &quot;s T-Shirts&quot;) or . = concat(&quot;Women&quot; , &quot;'&quot; , &quot;s T-Shirts&quot;))]</value>
   </webElementXpaths>
</WebElementEntity>
